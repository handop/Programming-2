﻿Public Class frmCustomerAddFlight
    Dim dblNonReservedTicket As Double
    Dim dblReservedTicket As Double
    'Loading cboFlights
    Private Sub frmCustomerAddFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim strFlightSelect As String
        Dim cmdFlightSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtFlights As DataTable = New DataTable
        Dim dtmTodaysDate As Date = Today


        strFlightSelect = "SELECT intFlightID, dtmFlightDate, strFlightNumber,  dtmTimeofDeparture, dtmTimeOfLanding " &
                          "FROM TFlights " &
                          "WHERE dtmFlightDate > '" & dtmTodaysDate & "'"

        cmdFlightSelect = New OleDb.OleDbCommand(strFlightSelect, m_conAdministrator)
        drSourceTable = cmdFlightSelect.ExecuteReader
        dtFlights.Load(drSourceTable)

        cboFlights.ValueMember = "intFlightID"
        cboFlights.DisplayMember = "strFlightNumber"
        cboFlights.DataSource = dtFlights


    End Sub

    'Populating lstFlightInfo based on the contents of cboFlights
    Private Sub cboFlights_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFlights.SelectedIndexChanged
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtmTodaysDate As Date = Today
        Dim intMilesFlown As Integer
        Dim intFlightID As Integer

        strSelect = "SELECT intFlightID, dtmFlightDate, strFlightNumber,  dtmTimeofDeparture, dtmTimeOfLanding, intFromAirportID, intToAirportID, intMilesFlown, intPlaneID " &
                    "FROM TFlights " &
                    "WHERE dtmFlightDate > '" & dtmTodaysDate & "' AND intFlightID = " & cboFlights.SelectedValue.ToString

        cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
        drSourceTable = cmdSelect.ExecuteReader

        drSourceTable.Read()

        intFlightID = drSourceTable("intFlightID")
        intMilesFlown = drSourceTable("intMilesFlown")


        lstFlightInfo.Items.Clear()
        lstFlightInfo.Items.Add("Flight Date: " & drSourceTable("dtmFlightDate"))
        lstFlightInfo.Items.Add("Flight Number: " & drSourceTable("strFlightNumber"))
        lstFlightInfo.Items.Add("Departure Time: " & drSourceTable("dtmTimeofDeparture"))
        lstFlightInfo.Items.Add("Arrival Time: " & drSourceTable("dtmTimeOfLanding"))

        dblNonReservedTicket = Calculate_dblNonReservedTicket(intMilesFlown, intFlightID)
        dblReservedTicket = Calculate_dblReservedTicket(intMilesFlown, intFlightID)

        radNonReserved.Text = "Seat Assigned At Check In: " & FormatCurrency(dblNonReservedTicket.ToString)
        radReserved.Text = "Seat Reserved : " & FormatCurrency(dblReservedTicket.ToString)
    End Sub
    'btnSubmit Main Routine
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'SQL Commands
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim strInsert As String
        Dim cmdInsert As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        'Other Necessary Variables
        Dim dblFlightCost As Double
        Dim Result As DialogResult
        Dim intNextPrimaryKey As Integer
        Dim intRowsAffected As Integer
        Dim blnValidated As Boolean
        Dim strSeat As String = ""

        Result = MessageBox.Show("Would you like to book Flight No." & cboFlights.Text & "?", "Confirm Booking", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

        Select Case Result
            Case DialogResult.Cancel
                MessageBox.Show("Action Canceled")
            Case DialogResult.No
                MessageBox.Show("Action Canceled")
            Case DialogResult.Yes

                Call Get_And_Validate_Input(blnValidated, dblFlightCost, strSeat)
                If blnValidated = True Then
                    strSelect = "SELECT MAX(intFlightPassengerID) + 1 AS intNextPrimaryKey " &
                    "From TFlightPassengers "

                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader

                    drSourceTable.Read()

                    If drSourceTable.IsDBNull(0) = True Then
                        intNextPrimaryKey = 1
                    Else
                        intNextPrimaryKey = CInt(drSourceTable(intNextPrimaryKey))
                    End If

                    strInsert = "INSERT INTO TFlightPassengers (intFlightPassengerID, intFlightID, intPassengerID, strSeat, mnyFlightCost) " &
                                "VALUES ( " & intNextPrimaryKey & ", " & cboFlights.SelectedValue & ", " & intPassengerID & ", '" & strSeat & "'," & dblFlightCost & ")"

                    cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                    intRowsAffected = cmdInsert.ExecuteNonQuery()

                    If intRowsAffected > 0 Then
                        MessageBox.Show("Flight has been booked!")
                    Else
                        CloseDatabaseConnection()
                    End If
                End If
        End Select
    End Sub
    'Getting and Validating Input
    Private Sub Get_And_Validate_Input(ByRef blnValidated As Boolean, ByRef dblFlightCost As Double, ByRef strSeat As String)
        Call Get_And_Validate_Flight(blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_Price(blnValidated, dblFlightCost, strSeat)
        End If
    End Sub
    'Getting and Validating Flight
    Private Sub Get_And_Validate_Flight(ByRef blnValidated As Boolean)
        If cboFlights.SelectedIndex = -1 Then
            MessageBox.Show("Please select a Flight.")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Getting and Validating Seat
    Private Sub Get_And_Validate_Price(ByRef blnValidated As Boolean, ByRef dblFlightCost As Double, ByRef strSeat As String)
        If radNonReserved.Checked = True Then
            dblFlightCost = dblNonReservedTicket
            strSeat = "AAC" '' Acronym For Assigned At Check in
            blnValidated = True
        ElseIf radReserved.Checked = True Then
            dblFlightCost = dblReservedTicket
            If cboSeats.SelectedIndex = -1 Then
                MessageBox.Show("Please Select a seat")
                blnValidated = False
            Else
                strSeat = cboSeats.SelectedValue
            End If
        Else
            MessageBox.Show("Please select a Ticket option")
            blnValidated = False
        End If
    End Sub
    'Calculating dblNonReservedTicket
    Private Function Calculate_dblNonReservedTicket(ByVal intMilesFlown As Integer, ByVal intFlightID As Integer) As Double
        Dim dblBaseCost As Double = 250
        Dim dblMilesCost As Double
        Dim dblBookedCost As Double
        Dim dblPlaneCost As Double
        Dim dblLandingCost As Double
        Dim dblAgeDiscount As Double
        Dim dblRepeatDiscount As Double

        dblMilesCost = Determine_dblMilesCost(intMilesFlown)
        dblBookedCost = Determine_dblBookedCost(intFlightID)
        dblPlaneCost = Determine_dblPlaneCost(intFlightID)
        dblLandingCost = Determine_dblLandingCost(intFlightID)
        dblAgeDiscount = Determine_dblAgeDiscount()
        dblRepeatDiscount = Determine_dblRepeatDiscount()

        Return dblAgeDiscount * dblRepeatDiscount * (dblBaseCost + dblMilesCost + dblBookedCost + dblPlaneCost + dblLandingCost)

    End Function
    'Calculating dblReservedTicket
    Private Function Calculate_dblReservedTicket(ByVal intMilesFlown As Integer, ByVal intFlightID As Integer) As Double
        Dim dblBaseCost As Double = 250
        Dim dblMilesCost As Double
        Dim dblBookedCost As Double
        Dim dblPlaneCost As Double
        Dim dblLandingCost As Double
        Dim dblAgeDiscount As Double
        Dim dblRepeatDiscount As Double

        dblMilesCost = Determine_dblMilesCost(intMilesFlown)
        dblBookedCost = Determine_dblBookedCost(intFlightID)
        dblPlaneCost = Determine_dblPlaneCost(intFlightID)
        dblLandingCost = Determine_dblLandingCost(intFlightID)
        dblAgeDiscount = Determine_dblAgeDiscount()
        dblRepeatDiscount = Determine_dblRepeatDiscount()

        Return dblAgeDiscount * dblRepeatDiscount * (dblBaseCost + dblMilesCost + dblBookedCost + dblPlaneCost + dblLandingCost + 125)

    End Function
    'Determining dblMilesCost
    Private Function Determine_dblMilesCost(ByVal intMilesFlown As Integer) As Double
        If intMilesFlown > 750 Then
            Return 50
        Else
            Return 0
        End If
    End Function
    'Determining dblBookedCost
    Private Function Determine_dblBookedCost(ByVal intFlightID As Integer) As Double
        Dim strAggregate As String
        Dim cmdAggregate As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        strAggregate = "SELECT COALESCE(COUNT(intPassengerID), 0) AS PassengerCount " &
                       "FROM TFlightPAssengers " &
                       "WHERE intFlightID = " & intFlightID
        cmdAggregate = New OleDb.OleDbCommand(strAggregate, m_conAdministrator)
        drSourceTable = cmdAggregate.ExecuteReader()
        drSourceTable.Read()

        If drSourceTable("PassengerCount") > 8 Then
            Return 100
        ElseIf drSourceTable("PassengerCount") < 4 Then
            Return -50
        Else
            Return 0
        End If
    End Function
    'Determining dblPlaneCost
    Private Function Determine_dblPlaneCost(ByVal intFlightID As Integer) As Double
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim strPlaneType As String

        strSelect = "SELECT TPl.strPlaneType " &
                    "FROM TPlaneTypes AS TPl INNER JOIN TPlanes AS TP ON TPl.intPlanetypeID = TP.intPlanetypeID INNER JOIN TFlights AS TF ON TF.intPlaneID = TP.intPlaneID " &
                    "WHERE TF.intFlightID = " & intFlightID
        cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
        drSourceTable = cmdSelect.ExecuteReader
        drSourceTable.Read()
        strPlaneType = drSourceTable("strPlaneType")

        If strPlaneType = "Airbus A350" Then
            Return 35.0
        ElseIf strPlaneType = "Boeing 747-8" Then
            Return -25
        Else
            Return 0
        End If

    End Function
    'Determining dblLandingCost
    Private Function Determine_dblLandingCost(ByVal intFlightID As Integer) As Double
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim strAirport As String

        strSelect = "SELECT TA.strAirportCode " &
            "FROM TFlights AS TF INNER JOIN TAirports AS TA ON TF.intToAirportID = TA.intAirportID " &
            "WHERE TF.intFlightID =" & intFlightID
        cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
        drSourceTable = cmdSelect.ExecuteReader
        drSourceTable.Read()
        strAirport = drSourceTable("strAirportCode")

        If strAirport = "MIA" Then
            Return 15
        Else
            Return 0
        End If
    End Function
    'Determining dblAgeDiscount
    Private Function Determine_dblAgeDiscount() As Double
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        strSelect = "SELECT FLOOR(DATEDIFF(DAY, dtmDateOfBirth, GetDate()) / 365.25) AS Age " &
                    "FROM TPassengers " &
                    "WHERE intPassengerID = " & intPassengerID
        cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
        drSourceTable = cmdSelect.ExecuteReader
        drSourceTable.Read()

        If drSourceTable("Age") >= 65 Then
            Return 0.8
        ElseIf drSourceTable("Age") <= 5 Then
            Return 0.35
        Else
            Return 1
        End If
    End Function
    'Determining dblRepeatDiscount
    Private Function Determine_dblRepeatDiscount() As Double
        Dim strAggregate As String
        Dim cmdAggregate As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtmTodaysDate As Date = Today

        strAggregate = "SELECT COUNT(intPassengerID) AS TimesFlown " &
                       "FROM TFlightPassengers AS TFP INNER JOIN TFlights AS TF ON TFP.intFlightID = TF.intFlightID " &
                       "WHERE TF.dtmFlightDate = '" & dtmTodaysDate & "' AND TFP.intPassengerID = " & intPassengerID
        cmdAggregate = New OleDb.OleDbCommand(strAggregate, m_conAdministrator)
        drSourceTable = cmdAggregate.ExecuteReader()
        drSourceTable.Read()
        If drSourceTable("TimesFlown") > 5 Then
            Return 0.9
        ElseIf drSourceTable("TimesFlown") > 10 Then
            Return 0.8
        Else
            Return 1
        End If

    End Function
    'Closing Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class