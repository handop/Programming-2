﻿Public Class frmAdminDeletePilot
    'USES STORED PROCEDURE uspListPilots
    'Selects Pilot First and Last Name and loads it into cboPilots
    Private Sub frmAdminDeletePilot_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cmdPilotSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtStates As DataTable = New DataTable
        Dim dtPilots As DataTable = New DataTable
        Dim blnValidated As Boolean

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                blnValidated = False
            Else
                blnValidated = True
            End If


            'Retrieving Pilot 
            cmdPilotSelect = New OleDb.OleDbCommand("uspListPilots", m_conAdministrator)
            cmdPilotSelect.CommandType = CommandType.StoredProcedure
            drSourceTable = cmdPilotSelect.ExecuteReader
            dtPilots.Load(drSourceTable)

            'Filling cboPassengers
            cboPilots.ValueMember = "intPilotID"
            cboPilots.DisplayMember = "PilotName"
            cboPilots.DataSource = dtPilots
        Catch excError As Exception
            MessageBox.Show(excError.Message)
        End Try
    End Sub
    'Deletes Pilot Info and all associated data in other Tables
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim intRowsAffected As Integer
        Dim Result As DialogResult
        Dim cmdDelete As New OleDb.OleDbCommand

        'Confirming the Selected Passenger should be Deleted
        Result = MessageBox.Show("Are you sure you want to DELETE " & cboPilots.Text & "'s  Data?", "Confirm Deletion", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

        Select Case Result
            Case DialogResult.Cancel
                MessageBox.Show("Action Canceled")
            Case DialogResult.No
                MessageBox.Show("Action Canceled")
            Case DialogResult.Yes
                cmdDelete.CommandText = "EXECUTE uspDeletePilot '" & cboPilots.SelectedValue & "'"
                cmdDelete.CommandType = CommandType.StoredProcedure
                cmdDelete = New OleDb.OleDbCommand(cmdDelete.CommandText, m_conAdministrator)
                intRowsAffected = cmdDelete.ExecuteNonQuery


                If intRowsAffected > 0 Then
                    MessageBox.Show("Deletion Successful")
                End If
        End Select
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class