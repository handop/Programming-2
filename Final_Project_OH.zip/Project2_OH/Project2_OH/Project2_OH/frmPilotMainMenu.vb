﻿Public Class frmPilotMainMenu
    'Opens frmPilotUpdateInfo
    Private Sub btnUpdateInfo_Click(sender As Object, e As EventArgs) Handles btnUpdateInfo.Click
        Dim frmUpdateInfo As New frmPilotUpdateInfo
        frmUpdateInfo.ShowDialog()
    End Sub
    'Opens frmPilotViewPastFlights
    Private Sub btnShowPastFlight_Click(sender As Object, e As EventArgs) Handles btnShowPastFlight.Click
        Dim frmPastFlights As New frmPilotViewPastFlights
        frmPastFlights.ShowDialog()
    End Sub
    'Opens frmPilotViewFutureFlights
    Private Sub btnShowFutureFlights_Click(sender As Object, e As EventArgs) Handles btnShowFutureFlights.Click
        Dim frmFutureFlights As New frmPilotViewFutureFlights
        frmFutureFlights.ShowDialog()
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class