﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminAddAttendantFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboAttendants = New System.Windows.Forms.ComboBox()
        Me.lblPilots = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lstFlightInfo = New System.Windows.Forms.ListBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.cboFlights = New System.Windows.Forms.ComboBox()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cboAttendants
        '
        Me.cboAttendants.FormattingEnabled = True
        Me.cboAttendants.Location = New System.Drawing.Point(257, 65)
        Me.cboAttendants.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboAttendants.Name = "cboAttendants"
        Me.cboAttendants.Size = New System.Drawing.Size(136, 28)
        Me.cboAttendants.TabIndex = 29
        '
        'lblPilots
        '
        Me.lblPilots.AutoSize = True
        Me.lblPilots.Location = New System.Drawing.Point(34, 68)
        Me.lblPilots.Name = "lblPilots"
        Me.lblPilots.Size = New System.Drawing.Size(204, 20)
        Me.lblPilots.TabIndex = 28
        Me.lblPilots.Text = "Please select an Attendant:"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(271, 305)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(122, 61)
        Me.btnExit.TabIndex = 27
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lstFlightInfo
        '
        Me.lstFlightInfo.FormattingEnabled = True
        Me.lstFlightInfo.ItemHeight = 20
        Me.lstFlightInfo.Location = New System.Drawing.Point(100, 124)
        Me.lstFlightInfo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lstFlightInfo.Name = "lstFlightInfo"
        Me.lstFlightInfo.Size = New System.Drawing.Size(222, 144)
        Me.lstFlightInfo.TabIndex = 26
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(37, 305)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(122, 61)
        Me.btnSubmit.TabIndex = 25
        Me.btnSubmit.Text = "Assign Attendant"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'cboFlights
        '
        Me.cboFlights.FormattingEnabled = True
        Me.cboFlights.Location = New System.Drawing.Point(257, 29)
        Me.cboFlights.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboFlights.Name = "cboFlights"
        Me.cboFlights.Size = New System.Drawing.Size(136, 28)
        Me.cboFlights.TabIndex = 24
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(34, 32)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(158, 20)
        Me.lblInstructions.TabIndex = 23
        Me.lblInstructions.Text = "Please select a flight:"
        '
        'frmAdminAddAttendantFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(426, 388)
        Me.Controls.Add(Me.cboAttendants)
        Me.Controls.Add(Me.lblPilots)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lstFlightInfo)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.cboFlights)
        Me.Controls.Add(Me.lblInstructions)
        Me.Name = "frmAdminAddAttendantFlight"
        Me.Text = "Assign Attendant"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboAttendants As ComboBox
    Friend WithEvents lblPilots As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents lstFlightInfo As ListBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents cboFlights As ComboBox
    Friend WithEvents lblInstructions As Label
End Class
