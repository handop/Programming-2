﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomerMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnShowPastFlight = New System.Windows.Forms.Button()
        Me.btnShowFutureFlights = New System.Windows.Forms.Button()
        Me.btnAddFlight = New System.Windows.Forms.Button()
        Me.btnUpdateInfo = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnShowPastFlight
        '
        Me.btnShowPastFlight.Location = New System.Drawing.Point(72, 196)
        Me.btnShowPastFlight.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnShowPastFlight.Name = "btnShowPastFlight"
        Me.btnShowPastFlight.Size = New System.Drawing.Size(152, 60)
        Me.btnShowPastFlight.TabIndex = 7
        Me.btnShowPastFlight.Text = "View Past Flights"
        Me.btnShowPastFlight.UseVisualStyleBackColor = True
        '
        'btnShowFutureFlights
        '
        Me.btnShowFutureFlights.Location = New System.Drawing.Point(72, 275)
        Me.btnShowFutureFlights.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnShowFutureFlights.Name = "btnShowFutureFlights"
        Me.btnShowFutureFlights.Size = New System.Drawing.Size(152, 60)
        Me.btnShowFutureFlights.TabIndex = 6
        Me.btnShowFutureFlights.Text = "View Upcoming Flights"
        Me.btnShowFutureFlights.UseVisualStyleBackColor = True
        '
        'btnAddFlight
        '
        Me.btnAddFlight.Location = New System.Drawing.Point(72, 117)
        Me.btnAddFlight.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnAddFlight.Name = "btnAddFlight"
        Me.btnAddFlight.Size = New System.Drawing.Size(152, 60)
        Me.btnAddFlight.TabIndex = 5
        Me.btnAddFlight.Text = "Book a Flight"
        Me.btnAddFlight.UseVisualStyleBackColor = True
        '
        'btnUpdateInfo
        '
        Me.btnUpdateInfo.Location = New System.Drawing.Point(72, 46)
        Me.btnUpdateInfo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdateInfo.Name = "btnUpdateInfo"
        Me.btnUpdateInfo.Size = New System.Drawing.Size(152, 52)
        Me.btnUpdateInfo.TabIndex = 4
        Me.btnUpdateInfo.Text = "Update Profile"
        Me.btnUpdateInfo.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(72, 352)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(152, 60)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmCustomerMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(306, 468)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnShowPastFlight)
        Me.Controls.Add(Me.btnShowFutureFlights)
        Me.Controls.Add(Me.btnAddFlight)
        Me.Controls.Add(Me.btnUpdateInfo)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmCustomerMainMenu"
        Me.Text = "Main Menu"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnShowPastFlight As Button
    Friend WithEvents btnShowFutureFlights As Button
    Friend WithEvents btnAddFlight As Button
    Friend WithEvents btnUpdateInfo As Button
    Friend WithEvents btnExit As Button
End Class
