﻿Public Class frmStartUpMenu
    'Opens Customer Login Form
    Private Sub btnPassengerLogin_Click(sender As Object, e As EventArgs) Handles btnPassengerLogin.Click
        Dim frmPassenger As New frmCustomerStartUp
        frmPassenger.ShowDialog()
    End Sub
    'Opens Employee Login Form
    Private Sub btnEmployeeLogin_Click(sender As Object, e As EventArgs) Handles btnEmployeeLogin.Click
        Dim frmEmployee As New frmEmployeeStartUp
        frmEmployee.ShowDialog()
    End Sub
    'Opens up the Stats Form
    Private Sub btnStatistics_Click(sender As Object, e As EventArgs) Handles btnStatistics.Click
        Dim frmStats As New frmStatistics
        frmStats.ShowDialog()
    End Sub
    'Closes the whole Application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        CloseDatabaseConnection()
        Application.Exit()
    End Sub
End Class