﻿Public Class frmAttendantStartUpMenu
    'Loads cboAttendants
    Private Sub frmAttendantStartUpMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cmdAttendantSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtAttendants As DataTable = New DataTable

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If


            'Retrieving those records
            cmdAttendantSelect = New OleDb.OleDbCommand("uspListAttendants", m_conAdministrator)
            cmdAttendantSelect.CommandType = CommandType.StoredProcedure
            drSourceTable = cmdAttendantSelect.ExecuteReader
            dtAttendants.Load(drSourceTable)

            'Filling cboAttendants
            cboAttendants.ValueMember = "intAttendantID"
            cboAttendants.DisplayMember = "AttendantName"
            cboAttendants.DataSource = dtAttendants

        Catch excError As Exception

            MessageBox.Show(excError.Message)

        End Try
    End Sub
    'Logs In selected Attendant
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If cboAttendants.SelectedIndex = -1 Then
            MessageBox.Show("Please select an Attendant Name")
        Else
            intAttendantID = cboAttendants.SelectedValue
            Dim frmAttendant As New frmAttendantMainMenu
            Close()
            frmAttendant.Show()
        End If
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class