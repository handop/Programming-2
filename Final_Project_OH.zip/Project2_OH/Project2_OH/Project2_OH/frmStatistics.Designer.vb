﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStatistics
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTotalPassengers = New System.Windows.Forms.Label()
        Me.lblTotalMiles = New System.Windows.Forms.Label()
        Me.lblAverageMiles = New System.Windows.Forms.Label()
        Me.lblAverageOutput = New System.Windows.Forms.Label()
        Me.lblTotalMilesOutput = New System.Windows.Forms.Label()
        Me.lblTotalPassengersOutput = New System.Windows.Forms.Label()
        Me.lstPilots = New System.Windows.Forms.ListBox()
        Me.lstAttendants = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(156, 544)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(113, 52)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTotalPassengers
        '
        Me.lblTotalPassengers.AutoSize = True
        Me.lblTotalPassengers.Location = New System.Drawing.Point(24, 34)
        Me.lblTotalPassengers.Name = "lblTotalPassengers"
        Me.lblTotalPassengers.Size = New System.Drawing.Size(214, 20)
        Me.lblTotalPassengers.TabIndex = 1
        Me.lblTotalPassengers.Text = "Total Number of Passengers:"
        '
        'lblTotalMiles
        '
        Me.lblTotalMiles.AutoSize = True
        Me.lblTotalMiles.Location = New System.Drawing.Point(24, 68)
        Me.lblTotalMiles.Name = "lblTotalMiles"
        Me.lblTotalMiles.Size = New System.Drawing.Size(263, 20)
        Me.lblTotalMiles.TabIndex = 2
        Me.lblTotalMiles.Text = "Total Miles Flown by All Passengers:"
        '
        'lblAverageMiles
        '
        Me.lblAverageMiles.AutoSize = True
        Me.lblAverageMiles.Location = New System.Drawing.Point(24, 103)
        Me.lblAverageMiles.Name = "lblAverageMiles"
        Me.lblAverageMiles.Size = New System.Drawing.Size(219, 20)
        Me.lblAverageMiles.TabIndex = 3
        Me.lblAverageMiles.Text = "Average Miles per Passenger:"
        '
        'lblAverageOutput
        '
        Me.lblAverageOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageOutput.Location = New System.Drawing.Point(305, 102)
        Me.lblAverageOutput.Name = "lblAverageOutput"
        Me.lblAverageOutput.Size = New System.Drawing.Size(123, 30)
        Me.lblAverageOutput.TabIndex = 6
        '
        'lblTotalMilesOutput
        '
        Me.lblTotalMilesOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalMilesOutput.Location = New System.Drawing.Point(305, 67)
        Me.lblTotalMilesOutput.Name = "lblTotalMilesOutput"
        Me.lblTotalMilesOutput.Size = New System.Drawing.Size(123, 30)
        Me.lblTotalMilesOutput.TabIndex = 5
        '
        'lblTotalPassengersOutput
        '
        Me.lblTotalPassengersOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalPassengersOutput.Location = New System.Drawing.Point(305, 33)
        Me.lblTotalPassengersOutput.Name = "lblTotalPassengersOutput"
        Me.lblTotalPassengersOutput.Size = New System.Drawing.Size(123, 31)
        Me.lblTotalPassengersOutput.TabIndex = 4
        '
        'lstPilots
        '
        Me.lstPilots.FormattingEnabled = True
        Me.lstPilots.ItemHeight = 20
        Me.lstPilots.Location = New System.Drawing.Point(55, 155)
        Me.lstPilots.Name = "lstPilots"
        Me.lstPilots.Size = New System.Drawing.Size(328, 164)
        Me.lstPilots.TabIndex = 7
        '
        'lstAttendants
        '
        Me.lstAttendants.FormattingEnabled = True
        Me.lstAttendants.ItemHeight = 20
        Me.lstAttendants.Location = New System.Drawing.Point(55, 358)
        Me.lstAttendants.Name = "lstAttendants"
        Me.lstAttendants.Size = New System.Drawing.Size(328, 164)
        Me.lstAttendants.TabIndex = 8
        '
        'frmStatistics
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(455, 608)
        Me.Controls.Add(Me.lstAttendants)
        Me.Controls.Add(Me.lstPilots)
        Me.Controls.Add(Me.lblAverageOutput)
        Me.Controls.Add(Me.lblTotalMilesOutput)
        Me.Controls.Add(Me.lblTotalPassengersOutput)
        Me.Controls.Add(Me.lblAverageMiles)
        Me.Controls.Add(Me.lblTotalMiles)
        Me.Controls.Add(Me.lblTotalPassengers)
        Me.Controls.Add(Me.btnExit)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmStatistics"
        Me.Text = "Statistics"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblTotalPassengers As Label
    Friend WithEvents lblTotalMiles As Label
    Friend WithEvents lblAverageMiles As Label
    Friend WithEvents lblAverageOutput As Label
    Friend WithEvents lblTotalMilesOutput As Label
    Friend WithEvents lblTotalPassengersOutput As Label
    Friend WithEvents lstPilots As ListBox
    Friend WithEvents lstAttendants As ListBox
End Class
