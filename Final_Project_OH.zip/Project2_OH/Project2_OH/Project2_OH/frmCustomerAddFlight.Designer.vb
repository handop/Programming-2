﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomerAddFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblSeatInstructions = New System.Windows.Forms.Label()
        Me.cboSeats = New System.Windows.Forms.ComboBox()
        Me.lstFlightInfo = New System.Windows.Forms.ListBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.cboFlights = New System.Windows.Forms.ComboBox()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.grpTicketPrices = New System.Windows.Forms.GroupBox()
        Me.radReserved = New System.Windows.Forms.RadioButton()
        Me.radNonReserved = New System.Windows.Forms.RadioButton()
        Me.grpTicketPrices.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(248, 434)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(122, 51)
        Me.btnExit.TabIndex = 13
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblSeatInstructions
        '
        Me.lblSeatInstructions.AutoSize = True
        Me.lblSeatInstructions.Location = New System.Drawing.Point(66, 96)
        Me.lblSeatInstructions.Name = "lblSeatInstructions"
        Me.lblSeatInstructions.Size = New System.Drawing.Size(133, 20)
        Me.lblSeatInstructions.TabIndex = 12
        Me.lblSeatInstructions.Text = "Choose your seat"
        '
        'cboSeats
        '
        Me.cboSeats.FormattingEnabled = True
        Me.cboSeats.Items.AddRange(New Object() {"1A", "2A", "3A", "4A", "5A", "1B", "2B", "3B", "4B", "5B", "1C", "2C", "3C", "4C", "5C", "1D", "2D", "3D", "4D", "5D"})
        Me.cboSeats.Location = New System.Drawing.Point(233, 92)
        Me.cboSeats.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboSeats.Name = "cboSeats"
        Me.cboSeats.Size = New System.Drawing.Size(136, 28)
        Me.cboSeats.TabIndex = 11
        '
        'lstFlightInfo
        '
        Me.lstFlightInfo.FormattingEnabled = True
        Me.lstFlightInfo.ItemHeight = 20
        Me.lstFlightInfo.Location = New System.Drawing.Point(107, 152)
        Me.lstFlightInfo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lstFlightInfo.Name = "lstFlightInfo"
        Me.lstFlightInfo.Size = New System.Drawing.Size(222, 144)
        Me.lstFlightInfo.TabIndex = 10
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(70, 434)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(122, 51)
        Me.btnSubmit.TabIndex = 9
        Me.btnSubmit.Text = "Book Flight"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'cboFlights
        '
        Me.cboFlights.FormattingEnabled = True
        Me.cboFlights.Location = New System.Drawing.Point(233, 42)
        Me.cboFlights.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboFlights.Name = "cboFlights"
        Me.cboFlights.Size = New System.Drawing.Size(136, 28)
        Me.cboFlights.TabIndex = 8
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(66, 46)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(158, 20)
        Me.lblInstructions.TabIndex = 7
        Me.lblInstructions.Text = "Please select a flight:"
        '
        'grpTicketPrices
        '
        Me.grpTicketPrices.Controls.Add(Me.radReserved)
        Me.grpTicketPrices.Controls.Add(Me.radNonReserved)
        Me.grpTicketPrices.Location = New System.Drawing.Point(12, 303)
        Me.grpTicketPrices.Name = "grpTicketPrices"
        Me.grpTicketPrices.Size = New System.Drawing.Size(412, 93)
        Me.grpTicketPrices.TabIndex = 14
        Me.grpTicketPrices.TabStop = False
        Me.grpTicketPrices.Text = "Ticket Prices:"
        '
        'radReserved
        '
        Me.radReserved.AutoSize = True
        Me.radReserved.Location = New System.Drawing.Point(31, 63)
        Me.radReserved.Name = "radReserved"
        Me.radReserved.Size = New System.Drawing.Size(133, 24)
        Me.radReserved.TabIndex = 1
        Me.radReserved.TabStop = True
        Me.radReserved.Text = "RadioButton2"
        Me.radReserved.UseVisualStyleBackColor = True
        '
        'radNonReserved
        '
        Me.radNonReserved.AutoSize = True
        Me.radNonReserved.Location = New System.Drawing.Point(31, 25)
        Me.radNonReserved.Name = "radNonReserved"
        Me.radNonReserved.Size = New System.Drawing.Size(133, 24)
        Me.radNonReserved.TabIndex = 0
        Me.radNonReserved.TabStop = True
        Me.radNonReserved.Text = "RadioButton1"
        Me.radNonReserved.UseVisualStyleBackColor = True
        '
        'frmCustomerAddFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(436, 507)
        Me.Controls.Add(Me.grpTicketPrices)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblSeatInstructions)
        Me.Controls.Add(Me.cboSeats)
        Me.Controls.Add(Me.lstFlightInfo)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.cboFlights)
        Me.Controls.Add(Me.lblInstructions)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmCustomerAddFlight"
        Me.Text = "Book a Flight!"
        Me.TopMost = True
        Me.grpTicketPrices.ResumeLayout(False)
        Me.grpTicketPrices.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblSeatInstructions As Label
    Friend WithEvents cboSeats As ComboBox
    Friend WithEvents lstFlightInfo As ListBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents cboFlights As ComboBox
    Friend WithEvents lblInstructions As Label
    Friend WithEvents grpTicketPrices As GroupBox
    Friend WithEvents radReserved As RadioButton
    Friend WithEvents radNonReserved As RadioButton
End Class
