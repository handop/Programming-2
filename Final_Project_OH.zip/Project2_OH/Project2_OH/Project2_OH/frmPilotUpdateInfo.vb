﻿Public Class frmPilotUpdateInfo
    'Loads Pilot Information and Fills cboPilotRoles
    Private Sub frmPilotUpdateInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim strPilotRoleSelect As String
        Dim cmdPilotRoleSelect As OleDb.OleDbCommand
        Dim strPilotSelect As String
        Dim cmdPilotSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtPilotRoles As DataTable = New DataTable
        Dim blnValidated As Boolean
        Dim dtmDateHired As Date
        Dim dtmDateFired As Date
        Dim dtmDateLicense As Date

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                blnValidated = False
            Else
                blnValidated = True
            End If

            strPilotRoleSelect = "SELECT intPilotRoleID, strPilotRole FROM TPilotRoles"
            cmdPilotRoleSelect = New OleDb.OleDbCommand(strPilotRoleSelect, m_conAdministrator)
            drSourceTable = cmdPilotRoleSelect.ExecuteReader
            dtPilotRoles.Load(drSourceTable)

            cboPilotRoles.ValueMember = "intPilotRoleID"
            cboPilotRoles.DisplayMember = "strPilotRole"
            cboPilotRoles.DataSource = dtPilotRoles

            'The select statement
            strPilotSelect = "SELECT TP.strFirstName, TP.strLastName, TP.strEmployeeID, TP.dtmDateofHire, TP.dtmDateofTermination, TP.dtmDateofLicense, TP.intPilotRoleID, TE.strUsername, TE.strPassword " &
                        "FROM TPilots AS TP INNER JOIN TEmployees AS TE ON TP.strEmployeeID = TE.strEmployeeID " &
                        "WHERE TP.intPilotID = " & intPilotID


            'Retrieving the Records
            cmdPilotSelect = New OleDb.OleDbCommand(strPilotSelect, m_conAdministrator)
            drSourceTable = cmdPilotSelect.ExecuteReader

            drSourceTable.Read()
            dtmDateHired = drSourceTable("dtmDateofHire")
            dtmDateFired = drSourceTable("dtmDateofTermination")
            dtmDateLicense = drSourceTable("dtmDateofLicense")

            'Filling in all Pilot Information
            txtFirstName.Text = drSourceTable("strFirstName")
            txtLastName.Text = drSourceTable("strLastName")
            txtEmployeeID.Text = drSourceTable("strEmployeeID")
            dtpDateHired.Text = dtmDateHired
            dtpDateFired.Text = dtmDateFired
            dtpDateLicense.Text = dtmDateLicense
            cboPilotRoles.SelectedValue = drSourceTable("intPilotRoleID")
            txtUsername.Text = drSourceTable("strUserName")
            txtPassword.Text = drSourceTable("strPassword")


        Catch excError As Exception

            MessageBox.Show(excError.Message)

        End Try
    End Sub
    'btnUpdate Main Routine
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strEmployeeID As String = ""
        Dim dtmDateHired As Date
        Dim dtmDateFired As Date
        Dim dtmDateLicense As Date
        Dim intPilotRole As Integer
        Dim blnValidated As Boolean
        Dim strUsername As String = ""
        Dim strPassword As String = ""

        Call Get_And_Validate_Input(strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, dtmDateLicense, intPilotRole, strUsername, strPassword, blnValidated)
        If blnValidated = True Then
            Call Update_Pilot_Info(strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, dtmDateLicense, intPilotRole, strUsername, strPassword)
        End If
    End Sub
    'Gets and Validates All Input
    Private Sub Get_And_Validate_Input(ByRef strFirstName As String, ByRef strLastName As String, ByRef strEmployeeID As String, ByRef dtmDateHired As Date, ByRef dtmDateFired As Date, ByRef dtmDateLicense As Date, ByRef intPilotRole As Integer, ByRef strUsername As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Call Get_And_Validate_strFirstName(strFirstName, blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_strLastName(strLastName, blnValidated)
            If blnValidated = True Then
                Call Get_And_Validate_strEmployeeID(strEmployeeID, blnValidated)
                If blnValidated = True Then
                    Call Get_And_Validate_strDateHired(dtmDateHired, blnValidated)
                    If blnValidated = True Then
                        Call Get_And_Validate_strDateFired(dtmDateFired, blnValidated)
                        If blnValidated = True Then
                            Call Get_And_Validate_strDateLicense(dtmDateLicense, blnValidated)
                            If blnValidated = True Then
                                Call Get_And_Validate_intPilotRole(intPilotRole, blnValidated)
                                If blnValidated = True Then
                                    Call Get_And_Validate_strUsername(strUsername, blnValidated)
                                    If blnValidated = True Then
                                        Call Get_And_Validate_strPassword(strPassword, blnValidated)
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    'Gets and Validates First Name
    Private Sub Get_And_Validate_strFirstName(ByRef strFirstName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtFirstName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a First Name.")
            blnValidated = False
            txtFirstName.Focus()
        Else
            strFirstName = txtFirstName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Last Name
    Private Sub Get_And_Validate_strLastName(ByRef strLastName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtLastName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Last Name.")
            blnValidated = False
            txtLastName.Focus()
        Else
            strLastName = txtLastName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates EmployeeID
    Private Sub Get_And_Validate_strEmployeeID(ByRef strEmployeeID As String, ByRef blnValidated As Boolean)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        If IsNumeric(txtEmployeeID.Text.Replace(" ", "")) = False Then
            MessageBox.Show("Please enter a 5 digit Employee ID")
            blnValidated = False
        Else
            strEmployeeID = txtEmployeeID.Text.Replace(" ", "")
            If strEmployeeID.Length <> 5 Then
                MessageBox.Show("Please enter a 5 digit Employee ID")
                txtEmployeeID.Focus()
                blnValidated = False
            Else
                strSelect = "SELECT COUNT(strEmployeeID) AS DoesExist FROM TEmployees WHERE strEmployeeID = '" & strEmployeeID & "'"
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader
                drSourceTable.Read()
                If drSourceTable("DoesExist") = 0 Then
                    blnValidated = True
                Else
                    MessageBox.Show("Given EmployeeID already exists in the database. Please enter a new one.")
                    blnValidated = False
                End If
            End If
        End If
    End Sub
    'Gets And Validates Date Hired
    Private Sub Get_And_Validate_strDateHired(ByRef dtmDateHired As Date, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDateHired.Value, dtmDateHired) = False Then
            MessageBox.Show("Please select a Hiring Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Date Fired
    Private Sub Get_And_Validate_strDateFired(ByRef dtmDateFired As String, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDateFired.Value, dtmDateFired) = False Then
            MessageBox.Show("Please select a Hiring Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Date License
    Private Sub Get_And_Validate_strDateLicense(ByRef dtmDateLicense As String, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDateLicense.Value, dtmDateLicense) = False Then
            MessageBox.Show("Please select a License Acquired Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Pilot Role
    Private Sub Get_And_Validate_intPilotRole(ByRef intPilotRole As Integer, ByRef blnValidated As Boolean)
        If cboPilotRoles.SelectedIndex = -1 Then
            MessageBox.Show("Please select a Pilot Role.")
            blnValidated = False
            cboPilotRoles.Focus()
        Else
            intPilotRole = cboPilotRoles.SelectedValue
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strUsername
    Private Sub Get_And_Validate_strUsername(ByRef strUsername As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef strPassword As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Password.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Updates Pilot Information
    Private Sub Update_Pilot_Info(ByVal strFirstName As String, ByVal strLastName As String, ByVal strEmployeeID As String, ByVal dtmDateHired As Date, ByVal dtmDateFired As Date, ByVal dtmDateLicense As Date, ByVal intPilotRole As Integer, ByVal strUsername As String, ByVal strPassword As String)
        Dim strUpdate As String
        Dim strEmpUpdate As String
        Dim cmdEmpUpdate As OleDb.OleDbCommand
        Dim cmdUpdate As OleDb.OleDbCommand
        Dim intRowsAffected As Integer

        strEmpUpdate = "UPDATE TEmployees SET " &
                       "strUsername = '" & strUsername & "', " &
                       "strPassword = '" & strPassword & "' " &
                       "WHERE strEmployeeID = '" & strEmployeeID & "'"

        cmdEmpUpdate = New OleDb.OleDbCommand(strEmpUpdate, m_conAdministrator)
        intRowsAffected = cmdEmpUpdate.ExecuteNonQuery()

        If intRowsAffected > 0 Then
            strUpdate = "UPDATE TPilots SET " &
            "strFirstName = '" & strFirstName & "'," &
            "strLastName = '" & strLastName & "'," &
            "strEmployeeID = '" & strEmployeeID & "'," &
            "dtmDateofHire = '" & dtmDateHired.ToString & "'," &
            "dtmDateofTermination = '" & dtmDateFired.ToString & "'," &
            "dtmDateofLicense = '" & dtmDateLicense.ToString & "'," &
            "intPilotRoleID = '" & intPilotRole & "' " &
            "WHERE intPilotID = " & intPilotID

            cmdUpdate = New OleDb.OleDbCommand(strUpdate, m_conAdministrator)

            intRowsAffected = cmdUpdate.ExecuteNonQuery()

            If intRowsAffected > 0 Then
                MessageBox.Show("Your Profile has been updated!")
            Else
                MessageBox.Show("There was a problem updating your information")
            End If
        End If
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class