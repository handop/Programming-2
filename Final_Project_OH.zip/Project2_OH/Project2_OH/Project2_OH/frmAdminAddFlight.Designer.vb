﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminAddFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtpFlightDate = New System.Windows.Forms.DateTimePicker()
        Me.lblFlightDate = New System.Windows.Forms.Label()
        Me.dtpArrivalTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpDepartureTime = New System.Windows.Forms.DateTimePicker()
        Me.lblDeparture = New System.Windows.Forms.Label()
        Me.lblArrival = New System.Windows.Forms.Label()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblFlightNumber = New System.Windows.Forms.Label()
        Me.txtFlightNumber = New System.Windows.Forms.TextBox()
        Me.cboDeparturePort = New System.Windows.Forms.ComboBox()
        Me.cboArrivalPort = New System.Windows.Forms.ComboBox()
        Me.txtDistanceTraveled = New System.Windows.Forms.TextBox()
        Me.cboPlaneID = New System.Windows.Forms.ComboBox()
        Me.lblFromAirport = New System.Windows.Forms.Label()
        Me.lblTooAirport = New System.Windows.Forms.Label()
        Me.lblMileage = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dtpFlightDate
        '
        Me.dtpFlightDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFlightDate.Location = New System.Drawing.Point(285, 58)
        Me.dtpFlightDate.MinDate = New Date(2023, 8, 19, 0, 0, 0, 0)
        Me.dtpFlightDate.Name = "dtpFlightDate"
        Me.dtpFlightDate.Size = New System.Drawing.Size(169, 26)
        Me.dtpFlightDate.TabIndex = 0
        '
        'lblFlightDate
        '
        Me.lblFlightDate.AutoSize = True
        Me.lblFlightDate.Location = New System.Drawing.Point(44, 63)
        Me.lblFlightDate.Name = "lblFlightDate"
        Me.lblFlightDate.Size = New System.Drawing.Size(91, 20)
        Me.lblFlightDate.TabIndex = 1
        Me.lblFlightDate.Text = "Flight Date:"
        '
        'dtpArrivalTime
        '
        Me.dtpArrivalTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpArrivalTime.Location = New System.Drawing.Point(285, 181)
        Me.dtpArrivalTime.MinDate = New Date(2023, 8, 19, 0, 0, 0, 0)
        Me.dtpArrivalTime.Name = "dtpArrivalTime"
        Me.dtpArrivalTime.ShowUpDown = True
        Me.dtpArrivalTime.Size = New System.Drawing.Size(169, 26)
        Me.dtpArrivalTime.TabIndex = 2
        Me.dtpArrivalTime.Value = New Date(2023, 8, 19, 16, 57, 0, 0)
        '
        'dtpDepartureTime
        '
        Me.dtpDepartureTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpDepartureTime.Location = New System.Drawing.Point(285, 140)
        Me.dtpDepartureTime.MinDate = New Date(2023, 8, 19, 0, 0, 0, 0)
        Me.dtpDepartureTime.Name = "dtpDepartureTime"
        Me.dtpDepartureTime.ShowUpDown = True
        Me.dtpDepartureTime.Size = New System.Drawing.Size(169, 26)
        Me.dtpDepartureTime.TabIndex = 3
        '
        'lblDeparture
        '
        Me.lblDeparture.AutoSize = True
        Me.lblDeparture.Location = New System.Drawing.Point(44, 145)
        Me.lblDeparture.Name = "lblDeparture"
        Me.lblDeparture.Size = New System.Drawing.Size(123, 20)
        Me.lblDeparture.TabIndex = 4
        Me.lblDeparture.Text = "Departure Time:"
        '
        'lblArrival
        '
        Me.lblArrival.AutoSize = True
        Me.lblArrival.Location = New System.Drawing.Point(44, 186)
        Me.lblArrival.Name = "lblArrival"
        Me.lblArrival.Size = New System.Drawing.Size(94, 20)
        Me.lblArrival.TabIndex = 5
        Me.lblArrival.Text = "Arrival Time:"
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(48, 415)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(132, 45)
        Me.btnSubmit.TabIndex = 6
        Me.btnSubmit.Text = "Add Flight"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(322, 415)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(132, 45)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblFlightNumber
        '
        Me.lblFlightNumber.AutoSize = True
        Me.lblFlightNumber.Location = New System.Drawing.Point(44, 102)
        Me.lblFlightNumber.Name = "lblFlightNumber"
        Me.lblFlightNumber.Size = New System.Drawing.Size(112, 20)
        Me.lblFlightNumber.TabIndex = 8
        Me.lblFlightNumber.Text = "Flight Number:"
        '
        'txtFlightNumber
        '
        Me.txtFlightNumber.Location = New System.Drawing.Point(285, 99)
        Me.txtFlightNumber.Name = "txtFlightNumber"
        Me.txtFlightNumber.Size = New System.Drawing.Size(169, 26)
        Me.txtFlightNumber.TabIndex = 9
        '
        'cboDeparturePort
        '
        Me.cboDeparturePort.FormattingEnabled = True
        Me.cboDeparturePort.Location = New System.Drawing.Point(285, 223)
        Me.cboDeparturePort.Name = "cboDeparturePort"
        Me.cboDeparturePort.Size = New System.Drawing.Size(169, 28)
        Me.cboDeparturePort.TabIndex = 10
        '
        'cboArrivalPort
        '
        Me.cboArrivalPort.FormattingEnabled = True
        Me.cboArrivalPort.Location = New System.Drawing.Point(285, 264)
        Me.cboArrivalPort.Name = "cboArrivalPort"
        Me.cboArrivalPort.Size = New System.Drawing.Size(169, 28)
        Me.cboArrivalPort.TabIndex = 11
        '
        'txtDistanceTraveled
        '
        Me.txtDistanceTraveled.Location = New System.Drawing.Point(285, 309)
        Me.txtDistanceTraveled.Name = "txtDistanceTraveled"
        Me.txtDistanceTraveled.Size = New System.Drawing.Size(169, 26)
        Me.txtDistanceTraveled.TabIndex = 12
        '
        'cboPlaneID
        '
        Me.cboPlaneID.FormattingEnabled = True
        Me.cboPlaneID.Location = New System.Drawing.Point(285, 352)
        Me.cboPlaneID.Name = "cboPlaneID"
        Me.cboPlaneID.Size = New System.Drawing.Size(169, 28)
        Me.cboPlaneID.TabIndex = 13
        '
        'lblFromAirport
        '
        Me.lblFromAirport.AutoSize = True
        Me.lblFromAirport.Location = New System.Drawing.Point(44, 226)
        Me.lblFromAirport.Name = "lblFromAirport"
        Me.lblFromAirport.Size = New System.Drawing.Size(136, 20)
        Me.lblFromAirport.TabIndex = 14
        Me.lblFromAirport.Text = "Departure Airport:"
        '
        'lblTooAirport
        '
        Me.lblTooAirport.AutoSize = True
        Me.lblTooAirport.Location = New System.Drawing.Point(44, 267)
        Me.lblTooAirport.Name = "lblTooAirport"
        Me.lblTooAirport.Size = New System.Drawing.Size(107, 20)
        Me.lblTooAirport.TabIndex = 15
        Me.lblTooAirport.Text = "Arrival Airport:"
        '
        'lblMileage
        '
        Me.lblMileage.AutoSize = True
        Me.lblMileage.Location = New System.Drawing.Point(44, 312)
        Me.lblMileage.Name = "lblMileage"
        Me.lblMileage.Size = New System.Drawing.Size(140, 20)
        Me.lblMileage.TabIndex = 16
        Me.lblMileage.Text = "Distance Traveled:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(44, 355)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 20)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Plane ID:"
        '
        'frmAdminAddFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(515, 506)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblMileage)
        Me.Controls.Add(Me.lblTooAirport)
        Me.Controls.Add(Me.lblFromAirport)
        Me.Controls.Add(Me.cboPlaneID)
        Me.Controls.Add(Me.txtDistanceTraveled)
        Me.Controls.Add(Me.cboArrivalPort)
        Me.Controls.Add(Me.cboDeparturePort)
        Me.Controls.Add(Me.txtFlightNumber)
        Me.Controls.Add(Me.lblFlightNumber)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.lblArrival)
        Me.Controls.Add(Me.lblDeparture)
        Me.Controls.Add(Me.dtpDepartureTime)
        Me.Controls.Add(Me.dtpArrivalTime)
        Me.Controls.Add(Me.lblFlightDate)
        Me.Controls.Add(Me.dtpFlightDate)
        Me.Name = "frmAdminAddFlight"
        Me.Text = "frmAdminAddFlight"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtpFlightDate As DateTimePicker
    Friend WithEvents lblFlightDate As Label
    Friend WithEvents dtpArrivalTime As DateTimePicker
    Friend WithEvents dtpDepartureTime As DateTimePicker
    Friend WithEvents lblDeparture As Label
    Friend WithEvents lblArrival As Label
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblFlightNumber As Label
    Friend WithEvents txtFlightNumber As TextBox
    Friend WithEvents cboDeparturePort As ComboBox
    Friend WithEvents cboArrivalPort As ComboBox
    Friend WithEvents txtDistanceTraveled As TextBox
    Friend WithEvents cboPlaneID As ComboBox
    Friend WithEvents lblFromAirport As Label
    Friend WithEvents lblTooAirport As Label
    Friend WithEvents lblMileage As Label
    Friend WithEvents Label5 As Label
End Class
