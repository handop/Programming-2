﻿Public Class frmCustomerMainMenu
    'Loads Database upon opening Page
    Private Sub frmCustomerMainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
    'Opens the Update Customer form
    Private Sub btnUpdateInfo_Click(sender As Object, e As EventArgs) Handles btnUpdateInfo.Click
        Dim frmUpdate As New frmCustomerUpdateInfo
        frmUpdate.ShowDialog()
    End Sub
    'Opens the Book a Flight form
    Private Sub btnAddFlight_Click(sender As Object, e As EventArgs) Handles btnAddFlight.Click
        Dim frmAddFlight As New frmCustomerAddFlight
        frmAddFlight.ShowDialog()
    End Sub
    'Opens the View Past Flights form
    Private Sub btnShowPastFlight_Click(sender As Object, e As EventArgs) Handles btnShowPastFlight.Click
        Dim frmViewPastFlights As New frmCustomerViewPastFlights
        frmViewPastFlights.ShowDialog()
    End Sub
    'Opens the View Future Flights form
    Private Sub btnShowFutureFlights_Click(sender As Object, e As EventArgs) Handles btnShowFutureFlights.Click
        Dim frmViewFutureFlights As New frmCustomerViewFutureFlights
        frmViewFutureFlights.ShowDialog()
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
