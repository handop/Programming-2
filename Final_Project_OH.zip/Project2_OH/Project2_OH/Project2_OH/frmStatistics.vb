﻿Public Class frmStatistics
    'USES STORED PROCEDURE uspSumTotalMiles
    'USES STORED PROCEDURE uspListAttendantsAndTotalMiles
    'Loads All Statistics
    Private Sub frmFlyMe2TheMoonStatistics_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        'SQL Commands
        Dim strTotalPassengers As String
        Dim cmdTotalPassengers As OleDb.OleDbCommand
        Dim cmdTotalMiles As OleDb.OleDbCommand
        Dim strPilotSelect As String
        Dim cmdPilotSelect As OleDb.OleDbCommand
        Dim cmdAttendantSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        'Other Important Variables
        Dim dtmTodaysDate As Date = Today
        Dim intNoPassengers As Integer
        Dim intTotalMiles As Integer
        Dim dblAverageMiles As Double

        'Selects and Displays Total Number of Passengers
        strTotalPassengers = "SELECT COUNT(intPassengerID) AS TotalPassengers FROM TPassengers"
        cmdTotalPassengers = New OleDb.OleDbCommand(strTotalPassengers, m_conAdministrator)
        drSourceTable = cmdTotalPassengers.ExecuteReader
        drSourceTable.Read()
        intNoPassengers = drSourceTable("TotalPassengers")
        lblTotalPassengersOutput.Text = intNoPassengers

        'Selects and Displays Total Miles Flown by All Passengers
        cmdTotalMiles = New OleDb.OleDbCommand("uspSumTotalMiles", m_conAdministrator)
        cmdTotalMiles.CommandType = CommandType.StoredProcedure
        drSourceTable = cmdTotalMiles.ExecuteReader
        drSourceTable.Read()
        intTotalMiles = drSourceTable("TotalMiles")
        lblTotalMilesOutput.Text = intTotalMiles

        'Calculates and Displays Average Miles Flown per Passenger
        dblAverageMiles = intTotalMiles / intNoPassengers
        lblAverageOutput.Text = dblAverageMiles

        'Selects and Displays each Pilot and Total Miles flown for each
        strPilotSelect = "SELECT TP.strLastName + ', ' + TP.strFirstName AS PilotName, COALESCE((SUM(TF.intMilesFlown)), 0) AS TotalMiles " &
                         "FROM TPilots AS TP LEFT JOIN TPilotFlights AS TPF ON TP.intPilotID = TPF.intPilotID LEFT JOIN TFlights AS TF ON TF.intFlightID = TPF.intFlightID " &
                         "GROUP BY TP.strLastName, TP.strFirstName " &
                         "ORDER BY TP.strLastName"
        cmdPilotSelect = New OleDb.OleDbCommand(strPilotSelect, m_conAdministrator)
        drSourceTable = cmdPilotSelect.ExecuteReader

        lstPilots.Items.Add("Pilot" & vbTab & vbTab & "Miles Flown")
        lstPilots.Items.Add("==================================================")

        While drSourceTable.Read
            If drSourceTable("PilotName").ToString.Length < 9 Then
                lstPilots.Items.Add(drSourceTable("PilotName") & vbTab & vbTab & drSourceTable("TotalMiles"))
            Else
                lstPilots.Items.Add(drSourceTable("PilotName") & vbTab & drSourceTable("TotalMiles"))
            End If

        End While

        'Selects and Displays Each Attendant and Total Miles Flown by each
        cmdAttendantSelect = New OleDb.OleDbCommand("uspListAttendantsAndTotalMiles", m_conAdministrator)
        cmdAttendantSelect.CommandType = CommandType.StoredProcedure
        drSourceTable = cmdAttendantSelect.ExecuteReader

        lstAttendants.Items.Add("Attendant" & vbTab & "Miles Flown")
        lstAttendants.Items.Add("==================================================")

        While drSourceTable.Read
            If drSourceTable("AttendantName").ToString.Length < 10 Then
                lstAttendants.Items.Add(drSourceTable("AttendantName") & vbTab & vbTab & drSourceTable("TotalMiles"))
            Else
                lstAttendants.Items.Add(drSourceTable("AttendantName") & vbTab & drSourceTable("TotalMiles"))
            End If
        End While

    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class