﻿Public Class frmAdminAddAttendant
    'Opens the Database upon loading
    Private Sub frmAdminAddAttendant_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Opening the Database
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
    'btnSubmit Main Routine
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim blnValidated As Boolean
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strEmployeeID As String = ""
        Dim dtmDateHired As Date
        Dim dtmDateFired As Date
        Dim strUsername As String = ""
        Dim strPassword As String = ""

        Call Get_And_Validate_Input(blnValidated, strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, strUsername, strPassword)
        If blnValidated = True Then
            Call Add_Attendant(strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, strUsername, strPassword)
        End If
    End Sub
    'Gets and Validates All Input
    Private Sub Get_And_Validate_Input(ByRef blnValidated As Boolean, ByRef strFirstName As String, ByRef strLastName As String, ByRef strEmployeeID As String, ByRef dtmDateHired As Date, ByRef dtmDateFired As Date, ByRef strUsername As String, ByRef strPassword As String)
        Call Get_And_Validate_strFirstName(blnValidated, strFirstName)
        If blnValidated = True Then
            Call Get_And_Validate_strLastName(blnValidated, strLastName)
            If blnValidated = True Then
                Call Get_And_Validate_strEmployeeID(blnValidated, strEmployeeID)
                If blnValidated = True Then
                    Call Get_And_Validate_dtmDateHired(blnValidated, dtmDateHired)
                    If blnValidated = True Then
                        Call Get_And_Validate_dtmDateFired(blnValidated, dtmDateFired)
                        If blnValidated = True Then
                            Call Get_And_Validate_strUsername(blnValidated, strUsername)
                            If blnValidated = True Then
                                Call Get_And_Validate_strPassword(blnValidated, strUsername)
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    'Gets and Validates First Name
    Private Sub Get_And_Validate_strFirstName(ByRef blnValidated As Boolean, ByRef strFirstName As String)
        If String.IsNullOrEmpty(txtFirstName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a First Name.")
            blnValidated = False
            txtFirstName.Focus()
        Else
            strFirstName = txtFirstName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Last Name
    Private Sub Get_And_Validate_strLastName(ByRef blnValidated As Boolean, ByRef strLastName As String)
        If String.IsNullOrEmpty(txtLastName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Last Name.")
            blnValidated = False
            txtLastName.Focus()
        Else
            strLastName = txtLastName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates EmployeeID
    Private Sub Get_And_Validate_strEmployeeID(ByRef blnValidated As Boolean, ByRef strEmployeeID As String)
        If IsNumeric(txtEmployeeID.Text.Replace(" ", "")) = False Then
            MessageBox.Show("Please enter a 5 digit Employee ID")
            blnValidated = False
        Else
            strEmployeeID = txtEmployeeID.Text.Replace(" ", "")
            If strEmployeeID.Length <> 5 Then
                MessageBox.Show("Please enter a 5 digit Employee ID")
                txtEmployeeID.Focus()
                blnValidated = False
            Else
                blnValidated = True
            End If
        End If
    End Sub
    'Gets And Validates Date Hired
    Private Sub Get_And_Validate_dtmDateHired(ByRef blnValidated As Boolean, ByRef dtmDateHired As Date)
        If Date.TryParse(dtpDateHired.Value, dtmDateHired) = False Then
            MessageBox.Show("Please select a Hiring Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Date Fired
    Private Sub Get_And_Validate_dtmDateFired(ByRef blnValidated As Boolean, ByRef dtmDateFired As Date)
        If Date.TryParse(dtpDateFired.Value, dtmDateFired) = False Then
            MessageBox.Show("Please select a Hiring Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates strUsername
    Private Sub Get_And_Validate_strUsername(ByRef blnValidated As Boolean, ByRef strUsername As String)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef blnValidated As Boolean, ByRef strPassword As String)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Passoword.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Adds Attendant Info To Database
    Private Sub Add_Attendant(ByVal strFirstName As String, ByVal strLastName As String, ByVal strEmployeeID As String, ByVal dtmDateHired As String, ByVal dtmDateFired As String, ByVal strUsername As String, ByVal strPassword As String)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim strEmpInsert As String
        Dim cmdEmpInsert As OleDb.OleDbCommand
        Dim strInsert As String
        Dim cmdInsert As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim intEmpNextPrimaryKey As Integer
        Dim intAttendantNextPrimaryKey As Integer
        Dim intRowsAffected As Integer

        strSelect = "SELECT MAX(intEmployeePK) + 1 AS intEmpNextPrimaryKey " &
                    "FROM TEmployees "


        'Running the Select Statement
        cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
        drSourceTable = cmdSelect.ExecuteReader

        'Checking if it is Null And Setting intNextPrimaryKey

        drSourceTable.Read()

        If drSourceTable.IsDBNull(0) = True Then
            intEmpNextPrimaryKey = 1
        Else
            intEmpNextPrimaryKey = CInt(drSourceTable(intEmpNextPrimaryKey))
        End If

        strEmpInsert = "INSERT INTO TEmployees (intEmployeePK, strUsername, strPassword, intEmployeeRoleID, strEmployeeID) " &
                        "VALUES (" & intEmpNextPrimaryKey & ",'" & strUsername & "','" & strPassword & "'," & 1 & ",'" & strEmployeeID & "')"
        cmdEmpInsert = New OleDb.OleDbCommand(strEmpInsert, m_conAdministrator)

        intRowsAffected = cmdEmpInsert.ExecuteNonQuery()
        If intRowsAffected > 0 Then
            strSelect = "SELECT MAX(intAttendantID) + 1 AS intAttendantNextPrimaryKey " &
                    "FROM TAttendants "
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'Checking if it is Null And Setting intNextPrimaryKey

            drSourceTable.Read()

            If drSourceTable.IsDBNull(0) = True Then
                intAttendantNextPrimaryKey = 1
            Else
                intAttendantNextPrimaryKey = CInt(drSourceTable(intAttendantNextPrimaryKey))
            End If
            strInsert = "INSERT INTO TAttendants (intAttendantID, strFirstName, strLastName, strEmployeeID, dtmDateofHire, dtmDateofTermination) " &
            "VALUES (" & intEmpNextPrimaryKey & ",'" & strFirstName & "','" & strLastName & "','" & strEmployeeID & "','" & dtmDateHired & "','" & dtmDateFired & "')"


            cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

            intRowsAffected = cmdInsert.ExecuteNonQuery()

            If intRowsAffected > 0 Then
                MessageBox.Show("Attendant Profile has been added.")
            Else
                CloseDatabaseConnection()
            End If
        Else
            CloseDatabaseConnection()
        End If


    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class