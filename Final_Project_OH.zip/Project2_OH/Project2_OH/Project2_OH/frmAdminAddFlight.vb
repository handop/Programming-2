﻿Public Class frmAdminAddFlight
    Dim dtmTodaysDate As DateTime = Today
    'Loads All comboboxes with assigned information
    Private Sub frmAdminAddFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim cmdAirports As OleDb.OleDbCommand
        Dim cmdPlanes As OleDb.OleDbCommand
        Dim dtAirports As New DataTable
        Dim dtAirports2 As New DataTable
        Dim dtPlanes As New DataTable

        cmdAirports = New OleDb.OleDbCommand("uspAirportCodes", m_conAdministrator)
        cmdAirports.CommandType = CommandType.StoredProcedure
        drSourceTable = cmdAirports.ExecuteReader
        dtAirports.Load(drSourceTable)

        cboDeparturePort.ValueMember = "intAirportID"
        cboDeparturePort.DisplayMember = "Airport"
        cboDeparturePort.DataSource = dtAirports

        cmdAirports = New OleDb.OleDbCommand("uspAirportCodes", m_conAdministrator)
        cmdAirports.CommandType = CommandType.StoredProcedure
        drSourceTable = cmdAirports.ExecuteReader
        dtAirports2.Load(drSourceTable)

        cboArrivalPort.ValueMember = "intAirportID"
        cboArrivalPort.DisplayMember = "Airport"
        cboArrivalPort.DataSource = dtAirports2

        cmdPlanes = New OleDb.OleDbCommand("uspPlanes", m_conAdministrator)
        cmdPlanes.CommandType = CommandType.StoredProcedure
        drSourceTable = cmdPlanes.ExecuteReader
        dtPlanes.Load(drSourceTable)

        cboPlaneID.ValueMember = "intPlaneID"
        cboPlaneID.DisplayMember = "strPlaneNumber"
        cboPlaneID.DataSource = dtPlanes

    End Sub
    'Submit Main Routine
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim dtmFlightDate As Date
        Dim strFlightNumber As String = ""
        Dim dtmDepartureTime As DateTime
        Dim dtmArrivalTime As DateTime
        Dim intDepartureAirport As Integer = 0
        Dim intArrivalAirport As Integer = 0
        Dim intMilesTraveled As Integer
        Dim intPlaneID As Integer = 0
        Dim blnValidated As Boolean

        Call Get_And_Validate_Input(dtmFlightDate, strFlightNumber, dtmDepartureTime, dtmArrivalTime, intMilesTraveled, blnValidated)
        If blnValidated = True Then
            Call Add_Flight(dtmFlightDate, strFlightNumber, dtmDepartureTime, dtmArrivalTime, intMilesTraveled)
        End If
    End Sub
    'Gets and Validates Input
    Private Sub Get_And_Validate_Input(ByRef dtmFlightDate As Date, ByRef strFlightNumber As String, ByRef dtmDepartureTime As DateTime, ByRef dtmArrivalTime As DateTime, ByRef intMilesTraveled As Integer, ByRef blnValidated As Boolean)
        Call Get_And_Validate_dtmFlightDate(dtmFlightDate, blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_strFlightNumber(strFlightNumber, blnValidated)
            If blnValidated = True Then
                Call Get_And_Validate_dtmDepartureTime(dtmDepartureTime, blnValidated)
                If blnValidated = True Then
                    Call Get_And_Validate_dtmArrivalTime(dtmDepartureTime, dtmArrivalTime, blnValidated)
                    If blnValidated = True Then
                        Call Get_And_Validate_intDepartureAirport(blnValidated)
                        If blnValidated = True Then
                            Call Get_And_Validate_intArrivalAirport(blnValidated)
                            If blnValidated = True Then
                                Call Get_And_Validate_intMilesTraveled(intMilesTraveled, blnValidated)
                                If blnValidated = True Then
                                    Call Get_And_Validate_intPlaneID(blnValidated)
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    'Gets and Validates dtmFlightDate
    Private Sub Get_And_Validate_dtmFlightDate(ByRef dtmFlightDate As Date, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpFlightDate.Value, dtmFlightDate) = False Then
            MessageBox.Show("Please select a Flight Date")
            blnValidated = False
        Else
            If dtmFlightDate < dtmTodaysDate Then
                MessageBox.Show("Please select a future Flight Date")
                blnValidated = False
            Else
                blnValidated = True
            End If
        End If
    End Sub
    'Gets and Validates strFlightNumber
    Private Sub Get_And_Validate_strFlightNumber(ByRef strFlightNumber As String, ByRef blnValidated As Boolean)
        Dim intTest As Integer
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        If Integer.TryParse(txtFlightNumber.Text, intTest) = True Then
            intTest = txtFlightNumber.Text
            strSelect = "SELECT COUNT(strFlightNumber) AS DoesExist FROM TFlights WHERE strFlightNumber = '" & intTest & "'"
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()
            If drSourceTable("DoesExist") = 0 Then
                strFlightNumber = intTest
                blnValidated = True
            Else
                MessageBox.Show(intTest & " already exists in another flight.")
                blnValidated = False
            End If
        Else
            MessageBox.Show("Please enter a Flight number.")
            txtFlightNumber.Focus()
            blnValidated = False
        End If
    End Sub
    'Gets and Validates dtmDepartureTime
    Private Sub Get_And_Validate_dtmDepartureTime(ByRef dtmDepartureTime As DateTime, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDepartureTime.Value.ToShortTimeString, dtmDepartureTime) = False Then
            MessageBox.Show("Please select a Departure Time")
            blnValidated = False
        Else
            dtmDepartureTime = dtpDepartureTime.Value
            If dtmDepartureTime < dtmTodaysDate Then
                MessageBox.Show("Please select a future Departure Time")
                blnValidated = False
            Else
                blnValidated = True
            End If
        End If
    End Sub
    'Gets and Validates dtmArrivalTime
    Private Sub Get_And_Validate_dtmArrivalTime(ByVal dtmDepartureTime As DateTime, ByRef dtmArrivalTime As DateTime, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpArrivalTime.Value.ToShortTimeString, dtmArrivalTime) = False Then
            MessageBox.Show("Please select a Departure Time")
            blnValidated = False
        Else
            dtmArrivalTime = dtpArrivalTime.Value.ToShortTimeString
            If dtmArrivalTime = dtmDepartureTime Then
                MessageBox.Show("You cannot depart and arrive at the same time.")
                blnValidated = False
            Else
                blnValidated = True
            End If
        End If
    End Sub
    'Validates Departure Airport
    Private Sub Get_And_Validate_intDepartureAirport(ByRef blnValidated As Boolean)
        If cboDeparturePort.SelectedIndex = -1 Then
            MessageBox.Show("Please Select a Departure Airport")
            blnValidated = False
            cboDeparturePort.Focus()
        Else
            blnValidated = True
        End If
    End Sub
    'Validates Arrival Airport
    Private Sub Get_And_Validate_intArrivalAirport(ByRef blnValidated As Boolean)
        If cboArrivalPort.SelectedIndex = -1 Then
            MessageBox.Show("Please Select an Arrival Airport")
            blnValidated = False
            cboArrivalPort.Focus()
        Else
            If cboArrivalPort.SelectedIndex = cboDeparturePort.SelectedIndex Then
                MessageBox.Show("You cannot depart and arrive at the same ariport.")
                blnValidated = False
                cboArrivalPort.Focus()
            Else
                blnValidated = True
            End If
        End If
    End Sub
    'Gets and Validates intMilesTraveled
    Private Sub Get_And_Validate_intMilesTraveled(ByRef intMilesTraveled As Integer, ByRef blnValidated As Boolean)
        If Integer.TryParse(txtDistanceTraveled.Text, intMilesTraveled) = True Then
            intMilesTraveled = txtDistanceTraveled.Text
            If intMilesTraveled <= 0 Then
                MessageBox.Show("Please enter a Travel Distance Larger Than 0 miles.")
                blnValidated = False
                txtDistanceTraveled.Focus()
            Else
                blnValidated = True
            End If
        Else
            MessageBox.Show("Please enter a Travel Distance in miles")
            blnValidated = False
            txtDistanceTraveled.Focus()
        End If
    End Sub
    'Validates intPlaneID
    Private Sub Get_And_Validate_intPlaneID(ByRef blnValidated As Boolean)
        If cboPlaneID.SelectedIndex = -1 Then
            MessageBox.Show("Please Select a Departure Airport")
            blnValidated = False
            cboPlaneID.Focus()
        Else
            blnValidated = True
        End If
    End Sub
    'Inserts Flight info into the database
    Private Sub Add_Flight(ByVal dtmFlightDate As Date, ByVal strFlightNumber As String, ByVal dtmDepartureTime As DateTime, ByVal dtmArrivalTime As DateTime, ByVal intMilesTraveled As Integer)
        Dim intFlightID = 0
        Dim cmdAddFlight As New OleDb.OleDbCommand
        Dim intRowsAffected As Integer

        cmdAddFlight.CommandText = "EXECUTE uspAddFlight '" & intFlightID & "','" & dtmFlightDate & "','" & strFlightNumber & "','" & dtmDepartureTime & "','" & dtmArrivalTime & "','" & cboDeparturePort.SelectedValue & "','" & cboArrivalPort.SelectedValue & "','" & intMilesTraveled & "','" & cboPlaneID.SelectedValue & "'"
        cmdAddFlight.CommandType = CommandType.StoredProcedure

        cmdAddFlight = New OleDb.OleDbCommand(cmdAddFlight.CommandText, m_conAdministrator)
        intRowsAffected = cmdAddFlight.ExecuteNonQuery

        If intRowsAffected > 0 Then
            MessageBox.Show("Flight Added!")
        Else
            MessageBox.Show("There was a problem adding the flight.")
        End If
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class