﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminAddPilotFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lstFlightInfo = New System.Windows.Forms.ListBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.cboFlights = New System.Windows.Forms.ComboBox()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.cboPilots = New System.Windows.Forms.ComboBox()
        Me.lblPilots = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(214, 302)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(122, 51)
        Me.btnExit.TabIndex = 20
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lstFlightInfo
        '
        Me.lstFlightInfo.FormattingEnabled = True
        Me.lstFlightInfo.ItemHeight = 20
        Me.lstFlightInfo.Location = New System.Drawing.Point(73, 122)
        Me.lstFlightInfo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lstFlightInfo.Name = "lstFlightInfo"
        Me.lstFlightInfo.Size = New System.Drawing.Size(222, 144)
        Me.lstFlightInfo.TabIndex = 17
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(36, 302)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(122, 51)
        Me.btnSubmit.TabIndex = 16
        Me.btnSubmit.Text = "Assign Pilot"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'cboFlights
        '
        Me.cboFlights.FormattingEnabled = True
        Me.cboFlights.Location = New System.Drawing.Point(200, 25)
        Me.cboFlights.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboFlights.Name = "cboFlights"
        Me.cboFlights.Size = New System.Drawing.Size(136, 28)
        Me.cboFlights.TabIndex = 15
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(33, 29)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(158, 20)
        Me.lblInstructions.TabIndex = 14
        Me.lblInstructions.Text = "Please select a flight:"
        '
        'cboPilots
        '
        Me.cboPilots.FormattingEnabled = True
        Me.cboPilots.Location = New System.Drawing.Point(200, 61)
        Me.cboPilots.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboPilots.Name = "cboPilots"
        Me.cboPilots.Size = New System.Drawing.Size(136, 28)
        Me.cboPilots.TabIndex = 22
        '
        'lblPilots
        '
        Me.lblPilots.AutoSize = True
        Me.lblPilots.Location = New System.Drawing.Point(33, 65)
        Me.lblPilots.Name = "lblPilots"
        Me.lblPilots.Size = New System.Drawing.Size(157, 20)
        Me.lblPilots.TabIndex = 21
        Me.lblPilots.Text = "Please Select a Pilot:"
        '
        'frmAdminAddPilotFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(386, 380)
        Me.Controls.Add(Me.cboPilots)
        Me.Controls.Add(Me.lblPilots)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lstFlightInfo)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.cboFlights)
        Me.Controls.Add(Me.lblInstructions)
        Me.Name = "frmAdminAddPilotFlight"
        Me.Text = "Assign Pilot"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lstFlightInfo As ListBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents cboFlights As ComboBox
    Friend WithEvents lblInstructions As Label
    Friend WithEvents cboPilots As ComboBox
    Friend WithEvents lblPilots As Label
End Class
