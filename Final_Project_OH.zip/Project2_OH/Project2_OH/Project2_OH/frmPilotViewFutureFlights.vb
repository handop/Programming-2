﻿Public Class frmPilotViewFutureFlights
    'Loads all flights going to be flown by selected Pilot
    Private Sub frmPilotViewFutureFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim strPastFlightsSelect As String
        Dim cmdPastFlightsSelect As OleDb.OleDbCommand
        Dim strAggregate As String
        Dim cmdAggregate As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtPastFlights As DataTable = New DataTable
        Dim dtmTodaysDate As Date = Today
        Dim dtmFlightDate As Date

        strPastFlightsSelect = "SELECT TF.intFlightID, TF.dtmFlightDate, TF.strFlightNumber, CAST(TF.dtmTimeofDeparture AS VARCHAR(5)) AS dtmTimeofDeparture, CAST(TF.dtmTimeOfLanding AS VARCHAR(5)) AS dtmTimeofLanding, TA1.strAirportCity AS Departing_City, TA2.strAirportCity AS Arrival_City  " &
                    "FROM TFlights AS TF INNER JOIN TAirports AS TA1 ON TF.intFromAirportID = TA1.intAirportID INNER JOIN TAirports AS TA2 ON TF.intToAirportID = TA2.intAirportID INNER JOIN TPilotFlights AS TPF ON TF.intFlightID = TPF.intFlightID  " &
                    "WHERE TF.dtmFlightDate >= '" & dtmTodaysDate.ToString & "' AND TPF.intPilotID = " & intPilotID


        cmdPastFlightsSelect = New OleDb.OleDbCommand(strPastFlightsSelect, m_conAdministrator)

        drSourceTable = cmdPastFlightsSelect.ExecuteReader

        lstFutureFlights.Items.Add("--Future Flights--")
        lstFutureFlights.Items.Add("===================================================================")


        While drSourceTable.Read
            dtmFlightDate = drSourceTable("dtmFlightDate")
            lstFutureFlights.Items.Add(" ")
            lstFutureFlights.Items.Add("Flight Number: " & drSourceTable("strFlightNumber"))
            lstFutureFlights.Items.Add("Date of Flight: " & dtmFlightDate.ToString)
            lstFutureFlights.Items.Add("Departure Location: " & drSourceTable("Departing_City"))
            lstFutureFlights.Items.Add("Departure Time: " & drSourceTable("dtmTimeofDeparture"))
            lstFutureFlights.Items.Add("Arrival Location: " & drSourceTable("Arrival_City"))
            lstFutureFlights.Items.Add("Arrival Time: " & drSourceTable("dtmTimeofLanding"))
            lstFutureFlights.Items.Add(" ")
            lstFutureFlights.Items.Add("===============================================================")
        End While

        strAggregate = "SELECT SUM(TF.intMilesFlown) AS TotalMiles " &
                       "FROM TFlights AS TF INNER JOIN TPilotFlights AS TPF ON TF.intFlightID = TPF.intFlightID " &
                       "WHERE TF.dtmFlightDate >=  '" & dtmTodaysDate & "' AND TPF.intPilotID = " & intPilotID

        cmdAggregate = New OleDb.OleDbCommand(strAggregate, m_conAdministrator)

        drSourceTable = cmdAggregate.ExecuteReader

        drSourceTable.Read()

        If IsDBNull(drSourceTable("TotalMiles")) = False Then
            lblTotalMilesOutput.Text = drSourceTable("TotalMiles")
        Else
            lblTotalMilesOutput.Text = "0"
        End If
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class