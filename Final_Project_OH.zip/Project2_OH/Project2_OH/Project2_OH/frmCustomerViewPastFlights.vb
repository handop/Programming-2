﻿Public Class frmCustomerViewPastFlights
    'USES STORED PROCEDURE uspListPastFlights
    'Loads All Customer's Past Flights and Sums up all flown miles
    Private Sub frmCustomerViewPastFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim cmdPastFlightsSelect As OleDb.OleDbCommand
        Dim strAggregate As String
        Dim cmdAggregate As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtPastFlights As DataTable = New DataTable
        Dim dtmTodaysDate As Date = Today
        Dim objParam As OleDb.OleDbParameter


        cmdPastFlightsSelect = New OleDb.OleDbCommand("uspListPastPassengerFlights", m_conAdministrator)
        cmdPastFlightsSelect.CommandType = CommandType.StoredProcedure

        objParam = cmdPastFlightsSelect.Parameters.Add("@dtmTodaysDate", OleDb.OleDbType.Date)
        objParam.Direction = ParameterDirection.Input
        objParam.Value = dtmTodaysDate

        objParam = cmdPastFlightsSelect.Parameters.Add("@intPassengerID", OleDb.OleDbType.Integer)
        objParam.Direction = ParameterDirection.Input
        objParam.Value = intPassengerID

        drSourceTable = cmdPastFlightsSelect.ExecuteReader

        lstPastFlights.Items.Add("--Past Flights--")
        lstPastFlights.Items.Add("===================================================================")


        While drSourceTable.Read
            lstPastFlights.Items.Add(" ")
            lstPastFlights.Items.Add("Flight Number: " & drSourceTable("strFlightNumber"))
            lstPastFlights.Items.Add("Date of Flight: " & drSourceTable("dtmFlightDate"))
            lstPastFlights.Items.Add("Departure Location: " & drSourceTable("Departing_City"))
            lstPastFlights.Items.Add("Departure Time: " & drSourceTable("dtmTimeofDeparture"))
            lstPastFlights.Items.Add("Arrival Location: " & drSourceTable("Arrival_City"))
            lstPastFlights.Items.Add("Arrival Time: " & drSourceTable("dtmTimeofLanding"))
            lstPastFlights.Items.Add(" ")
            lstPastFlights.Items.Add("===============================================================")
        End While

        strAggregate = "SELECT SUM(TF.intMilesFlown) AS Total_Miles_Flown " &
                       "FROM TFlights As TF INNER Join TFlightPassengers As TFP On TFP.intFlightID = TF.intFlightID " &
                       "WHERE TF.dtmFlightDate <  '" & dtmTodaysDate & "' AND TFP.intPassengerID =  " & intPassengerID

        cmdAggregate = New OleDb.OleDbCommand(strAggregate, m_conAdministrator)

        drSourceTable = cmdAggregate.ExecuteReader

        drSourceTable.Read()

        If IsDBNull(drSourceTable("Total_Miles_Flown")) = False Then
            lblTotalMilesOutput.Text = drSourceTable("Total_Miles_Flown")
        Else
            lblTotalMilesOutput.Text = "0"
        End If


    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class