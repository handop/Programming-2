﻿Public Class frmAttendantViewPastFlights
    'Loads all past flights flown by selected Attendant
    Private Sub frmAttendantViewPastFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim strPastFlightsSelect As String
        Dim cmdPastFlightsSelect As OleDb.OleDbCommand
        Dim strAggregate As String
        Dim cmdAggregate As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtPastFlights As DataTable = New DataTable
        Dim dtmTodaysDate As Date = Today
        Dim dtmFlightDate As Date

        strPastFlightsSelect = "SELECT TF.intFlightID, CONVERT(DATE, dtmFlightDate) AS dtmFlightDate, TF.strFlightNumber, CAST(TF.dtmTimeofDeparture AS VARCHAR(5)) AS dtmTimeofDeparture, CAST(TF.dtmTimeOfLanding AS VARCHAR(5)) AS dtmTimeofLanding, TA1.strAirportCity AS Departing_City, TA2.strAirportCity AS Arrival_City  " &
                               "FROM TFlights AS TF INNER JOIN TAirports AS TA1 ON TF.intFromAirportID = TA1.intAirportID INNER JOIN TAirports AS TA2 ON TF.intToAirportID = TA2.intAirportID INNER JOIN TAttendantFlights AS TAF ON TF.intFlightID = TAF.intFlightID  " &
                               "WHERE TF.dtmFlightDate < '" & dtmTodaysDate.ToString & "' AND TAF.intAttendantID = " & intAttendantID


        cmdPastFlightsSelect = New OleDb.OleDbCommand(strPastFlightsSelect, m_conAdministrator)

        drSourceTable = cmdPastFlightsSelect.ExecuteReader

        lstPastFlights.Items.Add("--Past Flights--")
        lstPastFlights.Items.Add("===================================================================")


        While drSourceTable.Read
            dtmFlightDate = drSourceTable("dtmFlightDate")
            lstPastFlights.Items.Add(" ")
            lstPastFlights.Items.Add("Flight Number: " & drSourceTable("strFlightNumber"))
            lstPastFlights.Items.Add("Date of Flight: " & dtmFlightDate)
            lstPastFlights.Items.Add("Departure Location: " & drSourceTable("Departing_City"))
            lstPastFlights.Items.Add("Departure Time: " & drSourceTable("dtmTimeofDeparture"))
            lstPastFlights.Items.Add("Arrival Location: " & drSourceTable("Arrival_City"))
            lstPastFlights.Items.Add("Arrival Time: " & drSourceTable("dtmTimeofLanding"))
            lstPastFlights.Items.Add(" ")
            lstPastFlights.Items.Add("===============================================================")
        End While

        strAggregate = "SELECT SUM(TF.intMilesFlown) AS TotalMiles " &
                       "FROM TFlights AS TF INNER JOIN TAttendantFlights AS TAF ON TAF.intFlightID = TF.intFlightID " &
                       "WHERE TAF.intAttendantID =  " & intAttendantID & " AND TF.dtmFlightDate <  '" & dtmTodaysDate & "'"

        cmdAggregate = New OleDb.OleDbCommand(strAggregate, m_conAdministrator)

        drSourceTable = cmdAggregate.ExecuteReader

        drSourceTable.Read()

        If IsDBNull(drSourceTable("TotalMiles")) = False Then
            lblTotalMilesOutput.Text = drSourceTable("TotalMiles")
        Else
            lblTotalMilesOutput.Text = "0"
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class