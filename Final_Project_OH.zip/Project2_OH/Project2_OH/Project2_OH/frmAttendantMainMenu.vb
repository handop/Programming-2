﻿Public Class frmAttendantMainMenu
    'Opens frmAttendantUpdateInfo
    Private Sub btnUpdateInfo_Click(sender As Object, e As EventArgs) Handles btnUpdateInfo.Click
        Dim frmUpdateProfile As New frmAttendantUpdateInfo
        frmUpdateProfile.ShowDialog()
    End Sub
    'Opens frmAttendantViewPastFlights
    Private Sub btnShowPastFlight_Click(sender As Object, e As EventArgs) Handles btnShowPastFlight.Click
        Dim frmViewPastFlights As New frmAttendantViewPastFlights
        frmViewPastFlights.ShowDialog()
    End Sub
    'Opens frmAttendantViewFutureFlights
    Private Sub btnShowFutureFlights_Click(sender As Object, e As EventArgs) Handles btnShowFutureFlights.Click
        Dim frmViewFutureFlights As New frmAttendantViewFutureFlights
        frmViewFutureFlights.ShowDialog()
    End Sub
    'Goes Back to Start Up Menu
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class