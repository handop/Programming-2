﻿Public Class frmAddPassenger
    'Populating cboStates
    Private Sub frmAddPassenger_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
        Dim dtStates As DataTable = New DataTable  ' this is the table we will load from our reader
        Dim blnValidated As Boolean

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                blnValidated = False
            Else
                blnValidated = True
            End If

            'Selecting Attendant ID and last name
            strSelect = "SELECT intStateID, strState FROM TStates"

            'Retrieving those Records
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtStates.Load(drSourceTable)

            'Loading the Combobox
            cboStates.ValueMember = "intStateID"
            cboStates.DisplayMember = "strState"
            cboStates.DataSource = dtStates
        Catch excError As Exception
            MessageBox.Show(excError.Message)
        End Try

    End Sub

    'Submit Main Routine
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim blnValidated As Boolean
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim dtmDateOfBirth As Date
        Dim strAddress As String = ""
        Dim strCity As String = ""
        Dim intState As Integer
        Dim strZIP As String = ""
        Dim strPhoneNo As String = ""
        Dim strEmail As String = ""
        Dim strUsername As String = ""
        Dim strPassword As String = ""

        Call Get_And_Validate_Input(strFirstName, strLastName, dtmDateOfBirth, strAddress, strCity, intState, strZIP, strPhoneNo, strEmail, strUsername, strPassword, blnValidated)
        If blnValidated = True Then
            Call Insert_New_Passenger(strFirstName, strLastName, dtmDateOfBirth, strAddress, strCity, intState, strZIP, strPhoneNo, strEmail, strUsername, strPassword)
        End If
    End Sub

    'Getting and Validating All Inputs
    Private Sub Get_And_Validate_Input(ByRef strFirstName As String, ByRef strLastName As String, ByRef dtmDateOfBirth As Date, ByRef strAddress As String, ByRef strCity As String, ByRef intState As Integer, ByRef strZIP As String, ByRef strPhoneNo As String, ByRef strEmail As String, ByRef strUsername As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Call Get_And_Validate_strFirstName(strFirstName, blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_strLastName(strLastName, blnValidated)
            If blnValidated = True Then
                Call Get_And_Validate_dtmDateOfBirth(dtmDateOfBirth, blnValidated)
                If blnValidated = True Then
                    Call Get_And_Validate_strAddress(strAddress, blnValidated)
                    If blnValidated = True Then
                        Call Get_And_Validate_strCity(strCity, blnValidated)
                        If blnValidated = True Then
                            Call Get_And_Validate_intState(intState, blnValidated)
                            If blnValidated = True Then
                                Call Get_And_Validate_strZIP(strZIP, blnValidated)
                                If blnValidated = True Then
                                    Call Get_And_Validate_strPhoneNo(strPhoneNo, blnValidated)
                                    If blnValidated = True Then
                                        strPhoneNo = Format_strPhoneNo(strPhoneNo)
                                        Call Get_And_Validate_strEmail(strEmail, blnValidated)
                                        If blnValidated = True Then
                                            Call Get_And_Validate_strUsername(strUsername, blnValidated)
                                            If blnValidated = True Then
                                                Call Get_And_Validate_strPassword(strPassword, blnValidated)
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If

    End Sub
    'Getting and Validating First Name
    Private Sub Get_And_Validate_strFirstName(ByRef strFirstName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtFirstName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a First Name.")
            blnValidated = False
            txtFirstName.Focus()
        Else
            strFirstName = txtFirstName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating Last Name
    Private Sub Get_And_Validate_strLastName(ByRef strLastName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtLastName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Last Name.")
            blnValidated = False
            txtLastName.Focus()
        Else
            strLastName = txtLastName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub

    Private Sub Get_And_Validate_dtmDateOfBirth(ByRef dtmDateOfBirth As Date, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDateOfBirth.Value, dtmDateOfBirth) = False Then
            MessageBox.Show("Please select your Date of Birth.")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Getting and Validating Address
    Private Sub Get_And_Validate_strAddress(ByRef strAddress As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtAddress.Text) Then
            MessageBox.Show("Please enter an Address.")
            blnValidated = False
            txtAddress.Focus()
        Else
            strAddress = txtAddress.Text
            blnValidated = True
        End If
    End Sub
    'Getting and Validating City
    Private Sub Get_And_Validate_strCity(ByRef strCity As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtCity.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a City.")
            blnValidated = False
            txtCity.Focus()
        Else
            strCity = txtCity.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating State
    Private Sub Get_And_Validate_intState(ByRef intState As Integer, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(cboStates.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a State.")
            blnValidated = False
            cboStates.Focus()
        Else
            intState = cboStates.SelectedIndex + 1
            blnValidated = True
        End If
    End Sub
    'Getting and Validating Zip
    Private Sub Get_And_Validate_strZIP(ByRef strZIP As String, ByRef blnValidated As Boolean)
        If IsNumeric(txtZIP.Text.Replace(" ", "")) Then
            strZIP = txtZIP.Text.Replace(" ", "")
            If strZIP.Length = 5 Then
                blnValidated = True
            Else
                MessageBox.Show("Please enter a 5 Digit Zip Code.")
                blnValidated = False
                txtZIP.Focus()
            End If
        Else
            MessageBox.Show("Please enter a 5 Digit Zip Code.")
            blnValidated = False
            txtZIP.Focus()
        End If
    End Sub
    'Getting and Validating Phone Number
    Private Sub Get_And_Validate_strPhoneNo(ByRef strPhoneNo As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPhoneNo.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Phone Number.")
            blnValidated = False
            txtPhoneNo.Focus()
        Else
            strPhoneNo = txtPhoneNo.Text.Replace(" ", "")
            If IsNumeric(strPhoneNo) = True Then
                If strPhoneNo.Length <> 10 Then
                    MessageBox.Show("Please enter a Phone Number equal to 10 digits.")
                    blnValidated = False
                    txtPhoneNo.Focus()
                End If
            Else
                MessageBox.Show("Please enter a phone number of 10 digits and no other symbols")
                blnValidated = False
                txtPhoneNo.Focus()
            End If

        End If


    End Sub
    'Formatting Phone Number
    Private Function Format_strPhoneNo(ByVal strPhoneNo As String) As String
        Dim strFormatPhoneNo As String
        strFormatPhoneNo = strPhoneNo
        strFormatPhoneNo = strFormatPhoneNo.Insert(3, "-")
        strFormatPhoneNo = strFormatPhoneNo.Insert(7, "-")
        strFormatPhoneNo = strFormatPhoneNo.Insert(0, "(")
        strFormatPhoneNo = strFormatPhoneNo.Insert(4, ")")

        Return strFormatPhoneNo
    End Function
    'Getting and Validating Email
    Private Sub Get_And_Validate_strEmail(ByRef strEmail As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtEmail.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a valid Email.")
            blnValidated = False
        Else
            strEmail = txtEmail.Text
            If strEmail.Contains("@") Then
                blnValidated = True
            Else
                MessageBox.Show("Please enter a valid Email.")
                blnValidated = False
            End If
        End If
    End Sub
    'Getting and Validating strUsername
    Private Sub Get_And_Validate_strUsername(ByRef strUsername As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef strPassword As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Passoword.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Inserting Passenger into the Database
    Private Sub Insert_New_Passenger(ByVal strFirstName As String, ByVal strLastName As String, ByVal dtmDateOfBirth As Date, ByVal strAddress As String, ByVal strCity As String, ByVal intState As Integer, ByVal strZIP As String, ByVal strPhoneNo As String, ByVal strEmail As String, ByVal strUsername As String, ByVal strPassword As String)
        Dim intRowsAffected As Integer
        Dim cmdAddPassenger As New OleDb.OleDbCommand
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        cmdAddPassenger.CommandText = "EXECUTE uspAddPassenger '" & intPassengerID & "','" & strFirstName & "','" & strLastName & "','" & dtmDateOfBirth & "','" & strAddress & "','" & strCity & "','" & intState & "','" & strZIP & "','" & strPhoneNo & "','" & strEmail & "','" & strUsername & "','" & strPassword & "'"
        cmdAddPassenger.CommandType = CommandType.StoredProcedure


        'Running the Select Statement
        cmdAddPassenger = New OleDb.OleDbCommand(cmdAddPassenger.CommandText, m_conAdministrator)

        intRowsAffected = cmdAddPassenger.ExecuteNonQuery()

        If intRowsAffected > 0 Then
            strSelect = "SELECT MAX(intPassengerID) AS intPassengerID FROM TPassengers "
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()
            intPassengerID = drSourceTable("intPassengerID")
            MessageBox.Show("Your profile has been created!")
            Dim frmCustomer As New frmCustomerMainMenu
            frmCustomer.Show()
            Close()
        Else
            MessageBox.Show("Profile not created")
        End If

    End Sub
    'Closing the Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
        Dim frmCustomer As New frmCustomerStartUp
        frmCustomer.Show()
    End Sub
End Class