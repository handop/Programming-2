﻿Public Class frmAdminMainMenu
    'Opens frmAdminAddPilot
    Private Sub btnAddPilot_Click(sender As Object, e As EventArgs) Handles btnAddPilot.Click
        Dim frmAddPilot As New frmAdminAddPilot
        frmAddPilot.ShowDialog()
    End Sub
    'Opens frmAdminDeletePilot
    Private Sub btnDeletePilot_Click(sender As Object, e As EventArgs) Handles btnDeletePilot.Click
        Dim frmDeletePilot As New frmAdminDeletePilot
        frmDeletePilot.ShowDialog()
    End Sub
    'Opens frmAdminAddPilotFlight
    Private Sub btnPilotAddFlight_Click(sender As Object, e As EventArgs) Handles btnPilotAddFlight.Click
        Dim frmAddPilotFlight As New frmAdminAddPilotFlight
        frmAddPilotFlight.ShowDialog()
    End Sub
    'Opens frmAdminAddAttendant
    Private Sub btnAddAttendant_Click(sender As Object, e As EventArgs) Handles btnAddAttendant.Click
        Dim frmAddAttendant As New frmAdminAddAttendant
        frmAddAttendant.ShowDialog()
    End Sub
    'Opens frmAdminDeleteAttendant
    Private Sub btnDeleteAttendant_Click(sender As Object, e As EventArgs) Handles btnDeleteAttendant.Click
        Dim frmDeleteAttendant As New frmAdminDeleteAttendant
        frmDeleteAttendant.ShowDialog()
    End Sub
    'Opens frmAdminAddAttendantFlight
    Private Sub btnAttendantAddFlight_Click(sender As Object, e As EventArgs) Handles btnAttendantAddFlight.Click
        Dim frmAddAttendantFlight As New frmAdminAddAttendantFlight
        frmAddAttendantFlight.ShowDialog()
    End Sub
    'Closes Page
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub

    Private Sub btnAddFlight_Click(sender As Object, e As EventArgs) Handles btnAddFlight.Click
        Dim frmAddFlight As New frmAdminAddFlight
        frmAdminAddFlight.ShowDialog()
    End Sub
End Class