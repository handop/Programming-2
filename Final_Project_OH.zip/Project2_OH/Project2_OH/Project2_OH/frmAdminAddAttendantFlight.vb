﻿Public Class frmAdminAddAttendantFlight
    'Loads cboFlights and cboAttentants
    Private Sub frmAdminAddAttendantFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim strFlightSelect As String
        Dim cmdFlightSelect As OleDb.OleDbCommand
        Dim cmdAttendantSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtFlights As DataTable = New DataTable
        Dim dtmTodaysDate As Date = Today
        Dim dtAttendants As DataTable = New DataTable


        strFlightSelect = "SELECT intFlightID, dtmFlightDate, strFlightNumber,  dtmTimeofDeparture, dtmTimeOfLanding " &
                          "FROM TFlights " &
                          "WHERE dtmFlightDate > '" & dtmTodaysDate & "'"

        cmdFlightSelect = New OleDb.OleDbCommand(strFlightSelect, m_conAdministrator)
        drSourceTable = cmdFlightSelect.ExecuteReader
        dtFlights.Load(drSourceTable)

        cboFlights.ValueMember = "intFlightID"
        cboFlights.DisplayMember = "strFlightNumber"
        cboFlights.DataSource = dtFlights

        'Retrieving Attendant Name
        cmdAttendantSelect = New OleDb.OleDbCommand("uspListAttendants", m_conAdministrator)
        cmdAttendantSelect.CommandType = CommandType.StoredProcedure
        drSourceTable = cmdAttendantSelect.ExecuteReader
        dtAttendants.Load(drSourceTable)

        'Filling cboPilots
        cboAttendants.ValueMember = "intAttendantID"
        cboAttendants.DisplayMember = "AttendantName"
        cboAttendants.DataSource = dtAttendants
    End Sub
    'Sets lstFlightInfo Content to current selected flight in cboFlights
    Private Sub cboFlights_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFlights.SelectedIndexChanged
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtmTodaysDate As Date = Today

        strSelect = "SELECT intFlightID, dtmFlightDate, strFlightNumber,  dtmTimeofDeparture, dtmTimeOfLanding " &
                    "FROM TFlights " &
                    "WHERE dtmFlightDate > '" & dtmTodaysDate & "' AND intFlightID = " & cboFlights.SelectedValue.ToString

        cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
        drSourceTable = cmdSelect.ExecuteReader

        drSourceTable.Read()

        lstFlightInfo.Items.Clear()
        lstFlightInfo.Items.Add("Flight Date: " & drSourceTable("dtmFlightDate"))
        lstFlightInfo.Items.Add("Flight Number: " & drSourceTable("strFlightNumber"))
        lstFlightInfo.Items.Add("Departure Time: " & drSourceTable("dtmTimeofDeparture"))
        lstFlightInfo.Items.Add("Arrival Time: " & drSourceTable("dtmTimeOfLanding"))
    End Sub
    'Adds Attendant and Flight to TAttendantFlights
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'SQL Commands
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim strInsert As String
        Dim cmdInsert As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        'Other Necessary Variables
        Dim Result As DialogResult
        Dim intNextPrimaryKey As Integer
        Dim intRowsAffected As Integer
        Dim blnValidated As Boolean

        Result = MessageBox.Show("Would you like to assign " & cboAttendants.Text & " to Flight No." & cboFlights.Text & "?", "Confirm Booking", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

        Select Case Result
            Case DialogResult.Cancel
                MessageBox.Show("Action Canceled")
            Case DialogResult.No
                MessageBox.Show("Action Canceled")
            Case DialogResult.Yes

                Call Get_And_Validate_Input(blnValidated)
                If blnValidated = True Then
                    strSelect = "SELECT MAX(intAttendantFlightID) + 1 AS intNextPrimaryKey " &
                    "From TAttendantFlights "

                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader

                    drSourceTable.Read()

                    If drSourceTable.IsDBNull(0) = True Then
                        intNextPrimaryKey = 1
                    Else
                        intNextPrimaryKey = CInt(drSourceTable(intNextPrimaryKey))
                    End If

                    strInsert = "INSERT INTO TAttendantFlights (intAttendantFlightID, intAttendantID, intFlightID) " &
                                "VALUES ( " & intNextPrimaryKey & ", " & cboAttendants.SelectedValue & ", " & cboFlights.SelectedValue & ")"

                    cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                    intRowsAffected = cmdInsert.ExecuteNonQuery()

                    If intRowsAffected > 0 Then
                        MessageBox.Show("Attendant has been added to Flight.")
                    Else
                        CloseDatabaseConnection()
                    End If
                End If
        End Select
    End Sub
    'Getting and Validating Input
    Private Sub Get_And_Validate_Input(ByRef blnValidated As Boolean)
        Call Get_And_Validate_Flight(blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_Attendant(blnValidated)
        End If
    End Sub
    'Getting and Validating Flight
    Private Sub Get_And_Validate_Flight(ByRef blnValidated As Boolean)
        If cboFlights.SelectedIndex = -1 Then
            MessageBox.Show("Please select a Flight.")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Getting and Validating Attendant
    Private Sub Get_And_Validate_Attendant(ByRef blnValidated As Boolean)
        If cboAttendants.SelectedIndex = -1 Then
            MessageBox.Show("Please Select a Pilot.")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class