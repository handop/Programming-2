﻿Public Class frmCustomerStartUp
    'Opening the Database upon opening page
    Private Sub frmCustomerStartUp_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch excError As Exception

            MessageBox.Show(excError.Message)

        End Try
    End Sub
    'Opens frmAddPassenger
    Private Sub btnCreateAccount_Click(sender As Object, e As EventArgs) Handles btnCreateAccount.Click
        Dim AddPassenger As New frmAddPassenger
        Close()
        AddPassenger.Show()
    End Sub
    'Opens Customer Main Menu
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim strUsername As String = ""
        Dim strPassword As String = ""
        Dim blnValidated As Boolean

        Call Get_And_Validate_Input(strUsername, strPassword, blnValidated)
        If blnValidated = True Then
            Call Log_User_In(strUsername, strPassword)
        End If
    End Sub
    'Gets and Validates Input
    Private Sub Get_And_Validate_Input(ByRef strUsername As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Call Get_And_Validate_strUsername(strUsername, blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_strPassword(strPassword, blnValidated)
        End If

    End Sub
    Private Sub Get_And_Validate_strUsername(ByRef strUsername As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef strPassword As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Passoword.")
            blnValidated = False
            txtPassword.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Attempts to Login User
    Private Sub Log_User_In(ByVal strUsername As String, ByVal strPassword As String)
        Dim cmdLogin As New OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        cmdLogin.CommandText = "EXECUTE uspCustomerLogin '" & strUsername & "','" & strPassword & "'"
        cmdLogin.CommandType = CommandType.StoredProcedure

        cmdLogin = New OleDb.OleDbCommand(cmdLogin.CommandText, m_conAdministrator)
        drSourceTable = cmdLogin.ExecuteReader

        drSourceTable.Read()

        If drSourceTable.HasRows = False Then
            MessageBox.Show("Error: Invalid Username or Password")
        Else
            MessageBox.Show("Login Successful!")
            intPassengerID = drSourceTable("intPassengerID")
            Dim frmCustomer As New frmCustomerMainMenu
            Close()
            frmCustomer.ShowDialog()
        End If

    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class