﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPilotMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnShowPastFlight = New System.Windows.Forms.Button()
        Me.btnShowFutureFlights = New System.Windows.Forms.Button()
        Me.btnUpdateInfo = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(79, 271)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(152, 60)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnShowPastFlight
        '
        Me.btnShowPastFlight.Location = New System.Drawing.Point(79, 115)
        Me.btnShowPastFlight.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnShowPastFlight.Name = "btnShowPastFlight"
        Me.btnShowPastFlight.Size = New System.Drawing.Size(152, 60)
        Me.btnShowPastFlight.TabIndex = 11
        Me.btnShowPastFlight.Text = "View Past Flights"
        Me.btnShowPastFlight.UseVisualStyleBackColor = True
        '
        'btnShowFutureFlights
        '
        Me.btnShowFutureFlights.Location = New System.Drawing.Point(79, 194)
        Me.btnShowFutureFlights.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnShowFutureFlights.Name = "btnShowFutureFlights"
        Me.btnShowFutureFlights.Size = New System.Drawing.Size(152, 60)
        Me.btnShowFutureFlights.TabIndex = 10
        Me.btnShowFutureFlights.Text = "View Upcoming Flights"
        Me.btnShowFutureFlights.UseVisualStyleBackColor = True
        '
        'btnUpdateInfo
        '
        Me.btnUpdateInfo.Location = New System.Drawing.Point(79, 46)
        Me.btnUpdateInfo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdateInfo.Name = "btnUpdateInfo"
        Me.btnUpdateInfo.Size = New System.Drawing.Size(152, 52)
        Me.btnUpdateInfo.TabIndex = 9
        Me.btnUpdateInfo.Text = "Update Profile"
        Me.btnUpdateInfo.UseVisualStyleBackColor = True
        '
        'frmPilotMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(332, 384)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnShowPastFlight)
        Me.Controls.Add(Me.btnShowFutureFlights)
        Me.Controls.Add(Me.btnUpdateInfo)
        Me.Name = "frmPilotMainMenu"
        Me.Text = "Main Menu"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnShowPastFlight As Button
    Friend WithEvents btnShowFutureFlights As Button
    Friend WithEvents btnUpdateInfo As Button
End Class
