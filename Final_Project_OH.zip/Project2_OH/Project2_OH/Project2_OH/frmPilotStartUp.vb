﻿Public Class frmPilotStartUp
    'Loads cboPilots
    Private Sub frmPilotStartUp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strPilotSelect As String
        Dim cmdPilotSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtPilots As DataTable = New DataTable
        Dim blnValidated As Boolean

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                blnValidated = False
            Else
                blnValidated = True
            End If

            'Selecting Pilot first and last name
            strPilotSelect = "SELECT intPilotID, strFirstName + ' ' + strLastName AS PilotName FROM TPilots"

            'Retrieving those records
            cmdPilotSelect = New OleDb.OleDbCommand(strPilotSelect, m_conAdministrator)
            drSourceTable = cmdPilotSelect.ExecuteReader
            dtPilots.Load(drSourceTable)

            'Filling cboPilots
            cboPilots.ValueMember = "intPilotID"
            cboPilots.DisplayMember = "PilotName"
            cboPilots.DataSource = dtPilots

        Catch excError As Exception

            MessageBox.Show(excError.Message)

        End Try
    End Sub
    'Opens Customer Main Menu
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If cboPilots.SelectedIndex = -1 Then
            MessageBox.Show("Please select a Pilot Name")
        Else
            intPilotID = cboPilots.SelectedValue
            Dim frmPilot As New frmPilotMainMenu
            Close()
            frmPilot.Show()
        End If
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class