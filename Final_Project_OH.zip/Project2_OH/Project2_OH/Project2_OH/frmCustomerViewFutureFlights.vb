﻿Public Class frmCustomerViewFutureFlights
    'Loads All Customer's Upcoming Flights and sum up the total miles that will be flown
    Private Sub frmCustomerViewFutureFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        'SQL Commands
        Dim cmdFutureFlightsSelect As OleDb.OleDbCommand
        Dim strAggregate As String
        Dim cmdAggregate As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtPastFlights As DataTable = New DataTable
        Dim objParam As OleDb.OleDbParameter
        'Getting Today's Date
        Dim dtmTodaysDate As Date = Today

        cmdFutureFlightsSelect = New OleDb.OleDbCommand("uspListFuturePassengerFlights", m_conAdministrator)
        cmdFutureFlightsSelect.CommandType = CommandType.StoredProcedure

        objParam = cmdFutureFlightsSelect.Parameters.Add("@dtmTodaysDate", OleDb.OleDbType.Date)
        objParam.Direction = ParameterDirection.Input
        objParam.Value = dtmTodaysDate

        objParam = cmdFutureFlightsSelect.Parameters.Add("@intPassengerID", OleDb.OleDbType.Integer)
        objParam.Direction = ParameterDirection.Input
        objParam.Value = intPassengerID

        drSourceTable = cmdFutureFlightsSelect.ExecuteReader

        lstFutureFlights.Items.Add("--Upcoming Flights--")
        lstFutureFlights.Items.Add("===================================================================")


        While drSourceTable.Read
            lstFutureFlights.Items.Add(" ")
            lstFutureFlights.Items.Add("Flight Number: " & drSourceTable("strFlightNumber"))
            lstFutureFlights.Items.Add("Date of Flight: " & drSourceTable("dtmFlightDate"))
            lstFutureFlights.Items.Add("Departure Location: " & drSourceTable("Departing_City"))
            lstFutureFlights.Items.Add("Departure Time: " & drSourceTable("dtmTimeofDeparture"))
            lstFutureFlights.Items.Add("Arrival Location: " & drSourceTable("Arrival_City"))
            lstFutureFlights.Items.Add("Arrival Time: " & drSourceTable("dtmTimeofLanding"))
            lstFutureFlights.Items.Add(" ")
            lstFutureFlights.Items.Add("===============================================================")
        End While

        strAggregate = "SELECT SUM(TF.intMilesFlown) AS Total_Miles_Flown " &
                       "FROM TFlights AS TF INNER JOIN TFlightPassengers AS TFP ON TFP.intFlightID = TF.intFlightID " &
                       "WHERE TFP.intPassengerID =  " & intPassengerID & " AND TF.dtmFlightDate >=  '" & dtmTodaysDate & "'"

        cmdAggregate = New OleDb.OleDbCommand(strAggregate, m_conAdministrator)

        drSourceTable = cmdAggregate.ExecuteReader

        drSourceTable.Read()

        If IsDBNull(drSourceTable("Total_Miles_Flown")) = False Then
            lblTotalMilesOutput.Text = drSourceTable("Total_Miles_Flown")
        Else
            lblTotalMilesOutput.Text = "0"
        End If

    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class