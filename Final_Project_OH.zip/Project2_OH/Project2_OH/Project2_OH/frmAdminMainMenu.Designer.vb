﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddPilot = New System.Windows.Forms.Button()
        Me.btnDeletePilot = New System.Windows.Forms.Button()
        Me.btnPilotAddFlight = New System.Windows.Forms.Button()
        Me.btnAddAttendant = New System.Windows.Forms.Button()
        Me.btnDeleteAttendant = New System.Windows.Forms.Button()
        Me.btnAttendantAddFlight = New System.Windows.Forms.Button()
        Me.grpManagePilots = New System.Windows.Forms.GroupBox()
        Me.grpManageAttendants = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnAddFlight = New System.Windows.Forms.Button()
        Me.grpManagePilots.SuspendLayout()
        Me.grpManageAttendants.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnAddPilot
        '
        Me.btnAddPilot.Location = New System.Drawing.Point(55, 49)
        Me.btnAddPilot.Name = "btnAddPilot"
        Me.btnAddPilot.Size = New System.Drawing.Size(148, 64)
        Me.btnAddPilot.TabIndex = 0
        Me.btnAddPilot.Text = "Add Pilot"
        Me.btnAddPilot.UseVisualStyleBackColor = True
        '
        'btnDeletePilot
        '
        Me.btnDeletePilot.Location = New System.Drawing.Point(55, 128)
        Me.btnDeletePilot.Name = "btnDeletePilot"
        Me.btnDeletePilot.Size = New System.Drawing.Size(148, 64)
        Me.btnDeletePilot.TabIndex = 1
        Me.btnDeletePilot.Text = "Delete Pilot"
        Me.btnDeletePilot.UseVisualStyleBackColor = True
        '
        'btnPilotAddFlight
        '
        Me.btnPilotAddFlight.Location = New System.Drawing.Point(55, 208)
        Me.btnPilotAddFlight.Name = "btnPilotAddFlight"
        Me.btnPilotAddFlight.Size = New System.Drawing.Size(148, 64)
        Me.btnPilotAddFlight.TabIndex = 2
        Me.btnPilotAddFlight.Text = "Assign Pilot to Flight"
        Me.btnPilotAddFlight.UseVisualStyleBackColor = True
        '
        'btnAddAttendant
        '
        Me.btnAddAttendant.Location = New System.Drawing.Point(56, 49)
        Me.btnAddAttendant.Name = "btnAddAttendant"
        Me.btnAddAttendant.Size = New System.Drawing.Size(148, 64)
        Me.btnAddAttendant.TabIndex = 3
        Me.btnAddAttendant.Text = "Add Attendant"
        Me.btnAddAttendant.UseVisualStyleBackColor = True
        '
        'btnDeleteAttendant
        '
        Me.btnDeleteAttendant.Location = New System.Drawing.Point(56, 128)
        Me.btnDeleteAttendant.Name = "btnDeleteAttendant"
        Me.btnDeleteAttendant.Size = New System.Drawing.Size(148, 64)
        Me.btnDeleteAttendant.TabIndex = 4
        Me.btnDeleteAttendant.Text = "Delete Attendant"
        Me.btnDeleteAttendant.UseVisualStyleBackColor = True
        '
        'btnAttendantAddFlight
        '
        Me.btnAttendantAddFlight.Location = New System.Drawing.Point(56, 208)
        Me.btnAttendantAddFlight.Name = "btnAttendantAddFlight"
        Me.btnAttendantAddFlight.Size = New System.Drawing.Size(148, 64)
        Me.btnAttendantAddFlight.TabIndex = 5
        Me.btnAttendantAddFlight.Text = "Assign Attendant to Flight"
        Me.btnAttendantAddFlight.UseVisualStyleBackColor = True
        '
        'grpManagePilots
        '
        Me.grpManagePilots.Controls.Add(Me.btnAddPilot)
        Me.grpManagePilots.Controls.Add(Me.btnDeletePilot)
        Me.grpManagePilots.Controls.Add(Me.btnPilotAddFlight)
        Me.grpManagePilots.Location = New System.Drawing.Point(48, 37)
        Me.grpManagePilots.Name = "grpManagePilots"
        Me.grpManagePilots.Size = New System.Drawing.Size(257, 301)
        Me.grpManagePilots.TabIndex = 6
        Me.grpManagePilots.TabStop = False
        Me.grpManagePilots.Text = "Manage Pilots"
        '
        'grpManageAttendants
        '
        Me.grpManageAttendants.Controls.Add(Me.btnAddAttendant)
        Me.grpManageAttendants.Controls.Add(Me.btnDeleteAttendant)
        Me.grpManageAttendants.Controls.Add(Me.btnAttendantAddFlight)
        Me.grpManageAttendants.Location = New System.Drawing.Point(400, 37)
        Me.grpManageAttendants.Name = "grpManageAttendants"
        Me.grpManageAttendants.Size = New System.Drawing.Size(257, 301)
        Me.grpManageAttendants.TabIndex = 7
        Me.grpManageAttendants.TabStop = False
        Me.grpManageAttendants.Text = "Manage Attendants"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(456, 344)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(148, 64)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Exit Page"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnAddFlight
        '
        Me.btnAddFlight.Location = New System.Drawing.Point(103, 344)
        Me.btnAddFlight.Name = "btnAddFlight"
        Me.btnAddFlight.Size = New System.Drawing.Size(148, 64)
        Me.btnAddFlight.TabIndex = 9
        Me.btnAddFlight.Text = "Add Flight"
        Me.btnAddFlight.UseVisualStyleBackColor = True
        '
        'frmAdminMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(717, 453)
        Me.Controls.Add(Me.btnAddFlight)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.grpManageAttendants)
        Me.Controls.Add(Me.grpManagePilots)
        Me.Name = "frmAdminMainMenu"
        Me.Text = "Main Menu"
        Me.TopMost = True
        Me.grpManagePilots.ResumeLayout(False)
        Me.grpManageAttendants.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnAddPilot As Button
    Friend WithEvents btnDeletePilot As Button
    Friend WithEvents btnPilotAddFlight As Button
    Friend WithEvents btnAddAttendant As Button
    Friend WithEvents btnDeleteAttendant As Button
    Friend WithEvents btnAttendantAddFlight As Button
    Friend WithEvents grpManagePilots As GroupBox
    Friend WithEvents grpManageAttendants As GroupBox
    Friend WithEvents Button1 As Button
    Friend WithEvents btnAddFlight As Button
End Class
