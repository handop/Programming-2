﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStartUpMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnStatistics = New System.Windows.Forms.Button()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.btnPassengerLogin = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnEmployeeLogin = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnStatistics
        '
        Me.btnStatistics.Location = New System.Drawing.Point(12, 268)
        Me.btnStatistics.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnStatistics.Name = "btnStatistics"
        Me.btnStatistics.Size = New System.Drawing.Size(151, 55)
        Me.btnStatistics.TabIndex = 13
        Me.btnStatistics.Text = "Flight Statistics"
        Me.btnStatistics.UseVisualStyleBackColor = True
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Location = New System.Drawing.Point(51, 36)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(288, 20)
        Me.lblInstructions.TabIndex = 11
        Me.lblInstructions.Text = "Welcome to FlyMe2TheMoon Air Travel!"
        '
        'btnPassengerLogin
        '
        Me.btnPassengerLogin.Location = New System.Drawing.Point(120, 84)
        Me.btnPassengerLogin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnPassengerLogin.Name = "btnPassengerLogin"
        Me.btnPassengerLogin.Size = New System.Drawing.Size(151, 55)
        Me.btnPassengerLogin.TabIndex = 12
        Me.btnPassengerLogin.Text = "Customer Login"
        Me.btnPassengerLogin.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(227, 269)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(151, 55)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "Exit Application"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnEmployeeLogin
        '
        Me.btnEmployeeLogin.Location = New System.Drawing.Point(120, 158)
        Me.btnEmployeeLogin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnEmployeeLogin.Name = "btnEmployeeLogin"
        Me.btnEmployeeLogin.Size = New System.Drawing.Size(151, 55)
        Me.btnEmployeeLogin.TabIndex = 15
        Me.btnEmployeeLogin.Text = "Employee Login"
        Me.btnEmployeeLogin.UseVisualStyleBackColor = True
        '
        'frmStartUpMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(390, 337)
        Me.Controls.Add(Me.btnEmployeeLogin)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnStatistics)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.btnPassengerLogin)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmStartUpMenu"
        Me.Text = "Welcome!"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnStatistics As Button
    Friend WithEvents lblInstructions As Label
    Friend WithEvents btnPassengerLogin As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnEmployeeLogin As Button
End Class
