﻿Public Class frmEmployeeStartUp
    'Opening the Database upon opening page
    Private Sub frmEmployeeStartUp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch excError As Exception

            MessageBox.Show(excError.Message)

        End Try
    End Sub
    'Login Main Routine
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim strUsername As String = ""
        Dim strPassword As String = ""
        Dim blnValidated As Boolean

        Call Get_And_Validate_Input(strUsername, strPassword, blnValidated)
        If blnValidated = True Then
            Call Log_User_In(strUsername, strPassword)
        End If
    End Sub
    'Gets and Validates Input
    Private Sub Get_And_Validate_Input(ByRef strUsername As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Call Get_And_Validate_strUsername(strUsername, blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_strPassword(strPassword, blnValidated)
        End If

    End Sub
    Private Sub Get_And_Validate_strUsername(ByRef strUsername As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef strPassword As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Passoword.")
            blnValidated = False
            txtPassword.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Attempts to Login User
    Private Sub Log_User_In(ByVal strUsername As String, ByVal strPassword As String)
        Dim cmdLogin As New OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim intRole As Integer
        Dim strEmployeeID As String

        cmdLogin.CommandText = "EXECUTE uspEmployeeLogin '" & strUsername & "','" & strPassword & "'"
        cmdLogin.CommandType = CommandType.StoredProcedure

        cmdLogin = New OleDb.OleDbCommand(cmdLogin.CommandText, m_conAdministrator)
        drSourceTable = cmdLogin.ExecuteReader

        drSourceTable.Read()

        If drSourceTable.HasRows = False Then
            MessageBox.Show("Error: Invalid Username or Password")
        Else
            MessageBox.Show("Login Successful!")
            intRole = drSourceTable("intEmployeeRoleID")
            strEmployeeID = drSourceTable("strEmployeeID")
            If intRole = 1 Then
                cmdLogin.CommandText = "EXECUTE uspPilotLogin '" & strEmployeeID & "'"
                cmdLogin.CommandType = CommandType.StoredProcedure
                cmdLogin = New OleDb.OleDbCommand(cmdLogin.CommandText, m_conAdministrator)
                drSourceTable = cmdLogin.ExecuteReader
                drSourceTable.Read()
                intPilotID = drSourceTable("intPilotID")
                Dim frmPilot As New frmPilotMainMenu
                Close()
                frmPilot.ShowDialog()
            ElseIf intRole = 2 Then
                cmdLogin.CommandText = "EXECUTE uspAttendantLogin '" & strEmployeeID & "'"
                cmdLogin.CommandType = CommandType.StoredProcedure
                cmdLogin = New OleDb.OleDbCommand(cmdLogin.CommandText, m_conAdministrator)
                drSourceTable = cmdLogin.ExecuteReader
                drSourceTable.Read()
                intAttendantID = drSourceTable("intAttendantID")
                Dim frmAttendant As New frmAttendantMainMenu
                Close()
                frmAttendant.ShowDialog()
            Else
                Dim frmAdmin As New frmAdminMainMenu
                frmAdmin.ShowDialog()
            End If
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class