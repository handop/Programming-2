﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAttendantUpdateInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.dtmDateFired = New System.Windows.Forms.Label()
        Me.lblDateHired = New System.Windows.Forms.Label()
        Me.lblEmployeeID = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.dtpDateHired = New System.Windows.Forms.DateTimePicker()
        Me.dtpDateFired = New System.Windows.Forms.DateTimePicker()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(319, 369)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(99, 39)
        Me.btnExit.TabIndex = 125
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(34, 369)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(99, 39)
        Me.btnUpdate.TabIndex = 124
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(214, 112)
        Me.txtEmployeeID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(204, 26)
        Me.txtEmployeeID.TabIndex = 120
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(214, 66)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(204, 26)
        Me.txtLastName.TabIndex = 119
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(214, 19)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(204, 26)
        Me.txtFirstName.TabIndex = 118
        '
        'dtmDateFired
        '
        Me.dtmDateFired.AutoSize = True
        Me.dtmDateFired.Location = New System.Drawing.Point(31, 204)
        Me.dtmDateFired.Name = "dtmDateFired"
        Me.dtmDateFired.Size = New System.Drawing.Size(157, 20)
        Me.dtmDateFired.TabIndex = 115
        Me.dtmDateFired.Text = "Last Date Employed:"
        '
        'lblDateHired
        '
        Me.lblDateHired.AutoSize = True
        Me.lblDateHired.Location = New System.Drawing.Point(31, 161)
        Me.lblDateHired.Name = "lblDateHired"
        Me.lblDateHired.Size = New System.Drawing.Size(90, 20)
        Me.lblDateHired.TabIndex = 114
        Me.lblDateHired.Text = "Date Hired:"
        '
        'lblEmployeeID
        '
        Me.lblEmployeeID.AutoSize = True
        Me.lblEmployeeID.Location = New System.Drawing.Point(31, 115)
        Me.lblEmployeeID.Name = "lblEmployeeID"
        Me.lblEmployeeID.Size = New System.Drawing.Size(104, 20)
        Me.lblEmployeeID.TabIndex = 113
        Me.lblEmployeeID.Text = "Employee ID:"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(31, 68)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(90, 20)
        Me.lblLastName.TabIndex = 112
        Me.lblLastName.Text = "Last Name:"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(31, 22)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(90, 20)
        Me.lblFirstName.TabIndex = 111
        Me.lblFirstName.Text = "First Name:"
        '
        'dtpDateHired
        '
        Me.dtpDateHired.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDateHired.Location = New System.Drawing.Point(214, 156)
        Me.dtpDateHired.Name = "dtpDateHired"
        Me.dtpDateHired.Size = New System.Drawing.Size(204, 26)
        Me.dtpDateHired.TabIndex = 126
        '
        'dtpDateFired
        '
        Me.dtpDateFired.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDateFired.Location = New System.Drawing.Point(214, 199)
        Me.dtpDateFired.Name = "dtpDateFired"
        Me.dtpDateFired.Size = New System.Drawing.Size(204, 26)
        Me.dtpDateFired.TabIndex = 127
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(30, 286)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(78, 20)
        Me.lblPassword.TabIndex = 131
        Me.lblPassword.Text = "Password"
        '
        'lblUserName
        '
        Me.lblUserName.AutoSize = True
        Me.lblUserName.Location = New System.Drawing.Point(30, 243)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(93, 20)
        Me.lblUserName.TabIndex = 130
        Me.lblUserName.Text = "User Name:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(214, 283)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(204, 26)
        Me.txtPassword.TabIndex = 129
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(214, 240)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(204, 26)
        Me.txtUsername.TabIndex = 128
        '
        'frmAttendantUpdateInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(444, 445)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblUserName)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.dtpDateFired)
        Me.Controls.Add(Me.dtpDateHired)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.txtEmployeeID)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.dtmDateFired)
        Me.Controls.Add(Me.lblDateHired)
        Me.Controls.Add(Me.lblEmployeeID)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Name = "frmAttendantUpdateInfo"
        Me.Text = "Update Profile"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnExit As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents dtmDateFired As Label
    Friend WithEvents lblDateHired As Label
    Friend WithEvents lblEmployeeID As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents dtpDateHired As DateTimePicker
    Friend WithEvents dtpDateFired As DateTimePicker
    Friend WithEvents lblPassword As Label
    Friend WithEvents lblUserName As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
End Class
