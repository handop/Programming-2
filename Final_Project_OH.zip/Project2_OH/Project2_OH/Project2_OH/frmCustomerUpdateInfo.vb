﻿Public Class frmCustomerUpdateInfo
    'Loads all Passenger Info and Fills cboStates
    Private Sub frmUpdatePassenger_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim strStatesSelect As String
        Dim cmdStatesSelect As OleDb.OleDbCommand
        Dim cmdPassengerSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtStates As DataTable = New DataTable
        Dim blnValidated As Boolean
        Dim objParam As OleDb.OleDbParameter

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                blnValidated = False
            Else
                blnValidated = True
            End If

            'Selecting States
            strStatesSelect = "SELECT intStateID, strState FROM TStates"

            'Retrieving those Records
            cmdStatesSelect = New OleDb.OleDbCommand(strStatesSelect, m_conAdministrator)
            drSourceTable = cmdStatesSelect.ExecuteReader
            dtStates.Load(drSourceTable)

            'Filling cboStates
            cboStates.ValueMember = "intStateID"
            cboStates.DisplayMember = "strState"
            cboStates.DataSource = dtStates

            'Retrieving the Records
            cmdPassengerSelect = New OleDb.OleDbCommand("uspListPassengerInfo", m_conAdministrator)
            cmdPassengerSelect.CommandType = CommandType.StoredProcedure

            objParam = cmdPassengerSelect.Parameters.Add("@intPassengerID", OleDb.OleDbType.Integer)
            objParam.Direction = ParameterDirection.Input
            objParam.Value = intPassengerID

            drSourceTable = cmdPassengerSelect.ExecuteReader
            drSourceTable.Read()

            'Filling in all Passenger Information
            txtFirstName.Text = drSourceTable("strFirstName")
            txtLastName.Text = drSourceTable("strLastName")
            dtpDateOfBirth.Text = drSourceTable("dtmDateofBirth")
            txtAddress.Text = drSourceTable("strAddress")
            txtCity.Text = drSourceTable("strCity")
            cboStates.SelectedValue = drSourceTable("intStateID")
            txtZIP.Text = drSourceTable("strZIP")
            txtPhoneNo.Text = drSourceTable("strPhoneNumber")
            txtEmail.Text = drSourceTable("strEmail")
            txtUsername.Text = drSourceTable("strUsername")
            txtPassword.Text = drSourceTable("strPassword")


        Catch excError As Exception

            MessageBox.Show(excError.Message)

        End Try

    End Sub
    'Update Main Routine
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Declaring all Passegner Info
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim dtmDateOfBirth As Date
        Dim strAddress As String = ""
        Dim strCity As String = ""
        Dim intState As Integer
        Dim strZIP As String = ""
        Dim strPhoneNo As String = ""
        Dim strEmail As String = ""
        Dim strUsername As String = ""
        Dim strPassword As String = ""
        Dim blnValidated As Boolean

        Call Get_And_Validate_Input(strFirstName, strLastName, dtmDateOfBirth, strAddress, strCity, intState, strZIP, strPhoneNo, strEmail, strUsername, strPassword, blnValidated)
        If blnValidated = True Then
            Call Update_Passenger_Info(strFirstName, strLastName, dtmDateOfBirth, strAddress, strCity, intState, strZIP, strPhoneNo, strEmail, strUsername, strPassword)
        End If


    End Sub
    'Getting and Validating All Inputs
    Private Sub Get_And_Validate_Input(ByRef strFirstName As String, ByRef strLastName As String, ByRef dtmDateOfBirth As Date, ByRef strAddress As String, ByRef strCity As String, ByRef intState As Integer, ByRef strZIP As String, ByRef strPhoneNo As String, ByRef strEmail As String, ByRef strUsername As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Call Get_And_Validate_strFirstName(strFirstName, blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_strLastName(strLastName, blnValidated)
            If blnValidated = True Then
                Call Get_And_Validate_dtmDateOfBirth(dtmDateOfBirth, blnValidated)
                If blnValidated = True Then
                    Call Get_And_Validate_strAddress(strAddress, blnValidated)
                    If blnValidated = True Then
                        Call Get_And_Validate_strCity(strCity, blnValidated)
                        If blnValidated = True Then
                            Call Get_And_Validate_intState(intState, blnValidated)
                            If blnValidated = True Then
                                Call Get_And_Validate_strZIP(strZIP, blnValidated)
                                If blnValidated = True Then
                                    Call Get_And_Validate_strPhoneNo(strPhoneNo, blnValidated)
                                    If blnValidated = True Then
                                        strPhoneNo = Format_strPhoneNo(strPhoneNo)
                                        Call Get_And_Validate_strEmail(strEmail, blnValidated)
                                        If blnValidated = True Then
                                            Call Get_And_Validate_strUsername(strUsername, blnValidated)
                                            If blnValidated = True Then
                                                Call Get_And_Validate_strPassword(strPassword, blnValidated)
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    'Gets and Validates First Name
    Private Sub Get_And_Validate_strFirstName(ByRef strFirstName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtFirstName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a First Name.")
            blnValidated = False
            txtFirstName.Focus()
        Else
            strFirstName = txtFirstName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Last Name
    Private Sub Get_And_Validate_strLastName(ByRef strLastName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtLastName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Last Name.")
            blnValidated = False
            txtLastName.Focus()
        Else
            strLastName = txtLastName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Date of Birth
    Private Sub Get_And_Validate_dtmDateOfBirth(ByRef dtmDateOfBirth As Date, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDateOfBirth.Value, dtmDateOfBirth) = False Then
            MessageBox.Show("Please select your Date of Birth.")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Address
    Private Sub Get_And_Validate_strAddress(ByRef strAddress As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtAddress.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter an Address.")
            blnValidated = False
            txtAddress.Focus()
        Else
            strAddress = txtAddress.Text
            blnValidated = True
        End If
    End Sub
    'Gets and Validates City
    Private Sub Get_And_Validate_strCity(ByRef strCity As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtCity.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a City.")
            blnValidated = False
            txtCity.Focus()
        Else
            strCity = txtCity.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates State
    Private Sub Get_And_Validate_intState(ByRef intState As Integer, ByRef blnValidated As Boolean)
        If cboStates.SelectedIndex = -1 Then
            MessageBox.Show("Please enter a State.")
            blnValidated = False
            cboStates.Focus()
        Else
            intState = cboStates.SelectedValue
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Zip
    Private Sub Get_And_Validate_strZIP(ByRef strZIP As String, ByRef blnValidated As Boolean)
        If IsNumeric(txtZIP.Text.Replace(" ", "")) Then
            strZIP = txtZIP.Text.Replace(" ", "")
            If strZIP.Length = 5 Then
                blnValidated = True
            Else
                MessageBox.Show("Please enter a 5 Digit Zip Code.")
                blnValidated = False
                txtZIP.Focus()
            End If
        Else
            MessageBox.Show("Please enter a 5 Digit Zip Code.")
            blnValidated = False
            txtZIP.Focus()
        End If
    End Sub
    'Gets and Validates Phone Number
    Private Sub Get_And_Validate_strPhoneNo(ByRef strPhoneNo As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPhoneNo.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Phone Number.")
            blnValidated = False
            txtPhoneNo.Focus()
        Else
            strPhoneNo = txtPhoneNo.Text.Replace(" ", "")
            If IsNumeric(strPhoneNo) = True Then
                If strPhoneNo.Length <> 10 Then
                    MessageBox.Show("Please enter a Phone Number of 10 digits with no formatting. We'll take care of it for you.")
                    blnValidated = False
                    txtPhoneNo.Focus()
                End If
            Else
                MessageBox.Show("Please enter a phone number of 10 digits and no other symbols")
                blnValidated = False
                txtPhoneNo.Focus()
            End If
        End If


    End Sub
    'Formats Phone Number
    Private Function Format_strPhoneNo(ByVal strPhoneNo As String) As String
        Dim strFormatPhoneNo As String
        strFormatPhoneNo = strPhoneNo
        strFormatPhoneNo = strFormatPhoneNo.Insert(3, "-")
        strFormatPhoneNo = strFormatPhoneNo.Insert(7, "-")
        strFormatPhoneNo = strFormatPhoneNo.Insert(0, "(")
        strFormatPhoneNo = strFormatPhoneNo.Insert(4, ")")

        Return strFormatPhoneNo
    End Function
    'Gets and Validates Email
    Private Sub Get_And_Validate_strEmail(ByRef strEmail As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtEmail.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a valid Email.")
            blnValidated = False
        Else
            strEmail = txtEmail.Text.Replace(" ", "")
            If strEmail.Contains("@") Then
                blnValidated = True
            Else
                MessageBox.Show("Please enter a valid Email.")
                blnValidated = False
            End If
        End If
    End Sub
    'Getting and Validating strUsername
    Private Sub Get_And_Validate_strUsername(ByRef strUsername As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef strPassword As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Password.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Updates Passenger Info
    Private Sub Update_Passenger_Info(ByVal strFirstName As String, ByVal strLastName As String, ByVal dtmDateOfBirth As Date, ByVal strAddress As String, ByVal strCity As String, ByVal intState As Integer, ByVal strZIP As String, ByVal strPhoneNo As String, ByVal strEmail As String, ByVal strUsername As String, ByVal strPassword As String)
        Dim cmdUpdate As New OleDb.OleDbCommand
        Dim intRowsAffected As Integer

        cmdUpdate.CommandText = "EXECUTE uspUpdatePassenger '" & intPassengerID & "','" & strFirstName & "','" & strLastName & "','" & dtmDateOfBirth & "','" & strAddress & "','" & strCity & "','" & intState & "','" & strZIP & "','" & strPhoneNo & "','" & strEmail & "','" & strUsername & "','" & strPassword & "'"
        cmdUpdate.CommandType = CommandType.StoredProcedure

        cmdUpdate = New OleDb.OleDbCommand(cmdUpdate.CommandText, m_conAdministrator)

        intRowsAffected = cmdUpdate.ExecuteNonQuery()

        If intRowsAffected > 0 Then
            MessageBox.Show("Your Profile has been updated!")
        Else
            CloseDatabaseConnection()
        End If

    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class