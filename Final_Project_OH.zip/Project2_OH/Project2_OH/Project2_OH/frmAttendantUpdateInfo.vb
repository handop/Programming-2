﻿Public Class frmAttendantUpdateInfo
    'Loads all selected Attendant's information
    Private Sub frmAttendantUpdateInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Dim strAttendantSelect As String
        Dim cmdAttendantSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dtAttentants As DataTable = New DataTable
        Dim blnValidated As Boolean
        Dim dtmDateHired As Date
        Dim dtmDateFired As Date

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                blnValidated = False
            Else
                blnValidated = True
            End If

            'The select statement
            strAttendantSelect = "SELECT TA.strFirstName, TA.strLastName, TA.strEmployeeID, TA.dtmDateofHire, TA.dtmDateofTermination, TE.strUsername, TE.strPassword " &
                        "FROM TAttendants AS TA INNER JOIN TEmployees AS TE ON TA.strEmployeeID = TE.strEmployeeID " &
                        "WHERE intAttendantID = " & intAttendantID


            'Retrieving the Records
            cmdAttendantSelect = New OleDb.OleDbCommand(strAttendantSelect, m_conAdministrator)
            drSourceTable = cmdAttendantSelect.ExecuteReader
            drSourceTable.Read()


            'Formatting Dates
            dtmDateHired = drSourceTable("dtmDateofHire")
            dtmDateFired = drSourceTable("dtmDateofTermination")

            'Filling in all Attendant Information
            txtFirstName.Text = drSourceTable("strFirstName")
            txtLastName.Text = drSourceTable("strLastName")
            txtEmployeeID.Text = drSourceTable("strEmployeeID")
            dtpDateHired.Text = dtmDateHired
            dtpDateFired.Text = dtmDateFired
            txtUsername.Text = drSourceTable("strUsername")
            txtPassword.Text = drSourceTable("strPassword")


        Catch excError As Exception

            MessageBox.Show(excError.Message)

        End Try
    End Sub
    'Update Main Routine
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strEmployeeID As String = ""
        Dim dtmDateHired As Date
        Dim dtmDateFired As Date
        Dim blnValidated As Boolean
        Dim strUsername As String = ""
        Dim strPassword As String = ""

        Call Get_And_Validate_Input(strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, strUsername, strPassword, blnValidated)
        If blnValidated = True Then
            Call Update_Attendant_Info(strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, strUsername, strPassword)
        End If
    End Sub
    'Gets and Validates All Input
    Private Sub Get_And_Validate_Input(ByRef strFirstName As String, ByRef strLastName As String, ByRef strEmployeeID As String, ByRef dtmDateHired As Date, ByRef dtmDateFired As Date, ByRef strUsername As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Call Get_And_Validate_strFirstName(strFirstName, blnValidated)
        If blnValidated = True Then
            Call Get_And_Validate_strLastName(strLastName, blnValidated)
            If blnValidated = True Then
                Call Get_And_Validate_strEmployeeID(strEmployeeID, blnValidated)
                If blnValidated = True Then
                    Call Get_And_Validate_strDateHired(dtmDateHired, blnValidated)
                    If blnValidated = True Then
                        Call Get_And_Validate_strDateFired(dtmDateFired, blnValidated)
                        If blnValidated = True Then
                            Call Get_And_Validate_strUsername(strUsername, blnValidated)
                            If blnValidated = True Then
                                Call Get_And_Validate_strPassword(strPassword, blnValidated)
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    'Gets and Validates First Name
    Private Sub Get_And_Validate_strFirstName(ByRef strFirstName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtFirstName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a First Name.")
            blnValidated = False
            txtFirstName.Focus()
        Else
            strFirstName = txtFirstName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Last Name
    Private Sub Get_And_Validate_strLastName(ByRef strLastName As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtLastName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Last Name.")
            blnValidated = False
            txtLastName.Focus()
        Else
            strLastName = txtLastName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates EmployeeID
    Private Sub Get_And_Validate_strEmployeeID(ByRef strEmployeeID As String, ByRef blnValidated As Boolean)
        If IsNumeric(txtEmployeeID.Text.Replace(" ", "")) = False Then
            MessageBox.Show("Please enter a 5 digit Employee ID")
            blnValidated = False
        Else
            strEmployeeID = txtEmployeeID.Text.Replace(" ", "")
            If strEmployeeID.Length <> 5 Then
                MessageBox.Show("Please enter a 5 digit Employee ID")
                txtEmployeeID.Focus()
                blnValidated = False
            Else
                blnValidated = True
            End If
        End If
    End Sub
    'Gets And Validates Date Hired
    Private Sub Get_And_Validate_strDateHired(ByRef dtmDateHired As Date, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDateHired.Value, dtmDateHired) = False Then
            MessageBox.Show("Please select a Hiring Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Date Fired
    Private Sub Get_And_Validate_strDateFired(ByRef dtmDateFired As String, ByRef blnValidated As Boolean)
        If Date.TryParse(dtpDateFired.Value, dtmDateFired) = False Then
            MessageBox.Show("Please select a Firing Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strUsername
    Private Sub Get_And_Validate_strUsername(ByRef strUsername As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef strPassword As String, ByRef blnValidated As Boolean)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Password.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Updates Attendant Info
    Private Sub Update_Attendant_Info(ByVal strFirstName As String, ByVal strLastName As String, ByVal strEmployeeID As String, ByVal dtmDateHired As Date, ByVal dtmDateFired As Date, ByVal strUsername As String, ByVal strPassword As String)
        Dim strEmpUpdate As String
        Dim cmdEmpUpdate As OleDb.OleDbCommand
        Dim strUpdate As String
        Dim cmdUpdate As OleDb.OleDbCommand
        Dim intRowsAffected As Integer

        strEmpUpdate = "UPDATE TEmployees SET " &
                       "strUsername = '" & strUsername & "', " &
                       "strPassword = '" & strPassword & "' " &
                       "WHERE strEmployeeID = '" & strEmployeeID & "'"

        cmdEmpUpdate = New OleDb.OleDbCommand(strEmpUpdate, m_conAdministrator)
        intRowsAffected = cmdEmpUpdate.ExecuteNonQuery()

        If intRowsAffected > 0 Then
            strUpdate = "UPDATE TAttendants SET " &
            "strFirstName = '" & strFirstName & "'," &
            "strLastName = '" & strLastName & "'," &
            "strEmployeeID = '" & strEmployeeID & "'," &
            "dtmDateofHire = '" & dtmDateHired.ToString & "'," &
            "dtmDateofTermination = '" & dtmDateFired.ToString & "'" &
            "WHERE intAttendantID = " & intAttendantID

            cmdUpdate = New OleDb.OleDbCommand(strUpdate, m_conAdministrator)

            intRowsAffected = cmdUpdate.ExecuteNonQuery()

            If intRowsAffected > 0 Then
                MessageBox.Show("Your Profile has been updated!")
            Else
                MessageBox.Show("There was an error updating your profile")
            End If
        Else
            MessageBox.Show("There was an error updating your profile")
        End If
    End Sub
    'Closes Page
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class