﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomerViewFutureFlights
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lstFutureFlights = New System.Windows.Forms.ListBox()
        Me.lblTotalMilesOutput = New System.Windows.Forms.Label()
        Me.lblTotalMiles = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(113, 281)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(111, 49)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Go Back"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lstFutureFlights
        '
        Me.lstFutureFlights.FormattingEnabled = True
        Me.lstFutureFlights.ItemHeight = 20
        Me.lstFutureFlights.Location = New System.Drawing.Point(14, 15)
        Me.lstFutureFlights.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lstFutureFlights.Name = "lstFutureFlights"
        Me.lstFutureFlights.Size = New System.Drawing.Size(303, 184)
        Me.lstFutureFlights.TabIndex = 10
        '
        'lblTotalMilesOutput
        '
        Me.lblTotalMilesOutput.BackColor = System.Drawing.SystemColors.Control
        Me.lblTotalMilesOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalMilesOutput.Location = New System.Drawing.Point(205, 218)
        Me.lblTotalMilesOutput.Name = "lblTotalMilesOutput"
        Me.lblTotalMilesOutput.Size = New System.Drawing.Size(112, 29)
        Me.lblTotalMilesOutput.TabIndex = 9
        '
        'lblTotalMiles
        '
        Me.lblTotalMiles.AutoSize = True
        Me.lblTotalMiles.Location = New System.Drawing.Point(14, 219)
        Me.lblTotalMiles.Name = "lblTotalMiles"
        Me.lblTotalMiles.Size = New System.Drawing.Size(164, 20)
        Me.lblTotalMiles.TabIndex = 8
        Me.lblTotalMiles.Text = "Total Upcoming Miles:"
        '
        'frmCustomerViewFutureFlights
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(339, 359)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lstFutureFlights)
        Me.Controls.Add(Me.lblTotalMilesOutput)
        Me.Controls.Add(Me.lblTotalMiles)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmCustomerViewFutureFlights"
        Me.Text = "Upcoming Flights"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lstFutureFlights As ListBox
    Friend WithEvents lblTotalMilesOutput As Label
    Friend WithEvents lblTotalMiles As Label
End Class
