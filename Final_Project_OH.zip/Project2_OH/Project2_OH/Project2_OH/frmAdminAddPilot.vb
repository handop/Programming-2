﻿Public Class frmAdminAddPilot
    'Loads cboPilotRoles
    Private Sub frmAdminAddPilot_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
        Dim dtPilotRoles As DataTable = New DataTable  ' this is the table we will load from our reader

        Try
            'Opening the Database
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
            End If

            'Selecting Attendant ID and last name
            strSelect = "SELECT intPilotRoleID, strPilotRole FROM TPilotRoles"

            'Retrieving those Records
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtPilotRoles.Load(drSourceTable)

            'Loading the Combobox
            cboPilotRoles.ValueMember = "intPilotRoleID"
            cboPilotRoles.DisplayMember = "strPilotRole"
            cboPilotRoles.DataSource = dtPilotRoles
        Catch excError As Exception
            MessageBox.Show(excError.Message)
        End Try
    End Sub
    'Add Pilot Main Routine
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim blnValidated As Boolean
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strEmployeeID As String = ""
        Dim dtmDateHired As Date
        Dim dtmDateFired As Date
        Dim dtmDateLicense As Date
        Dim strUsername As String = ""
        Dim strPassword As String = ""

        Call Get_And_Validate_Input(blnValidated, strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, dtmDateLicense, strUsername, strPassword)
        If blnValidated = True Then
            Call Add_Pilot(strFirstName, strLastName, strEmployeeID, dtmDateHired, dtmDateFired, dtmDateLicense, strUsername, strPassword)
        End If

    End Sub
    'Gets and Validates All Input
    Private Sub Get_And_Validate_Input(ByRef blnValidated As Boolean, ByRef strFirstName As String, ByRef strLastName As String, ByRef strEmployeeID As String, ByRef dtmDateHired As Date, ByRef dtmDateFired As Date, ByRef dtmDateLicense As Date, ByRef strUsername As String, ByRef strPassword As String)
        Call Get_And_Validate_strFirstName(blnValidated, strFirstName)
        If blnValidated = True Then
            Call Get_And_Validate_strLastName(blnValidated, strLastName)
            If blnValidated = True Then
                Call Get_And_Validate_strEmployeeID(blnValidated, strEmployeeID)
                If blnValidated = True Then
                    Call Get_And_Validate_dtmDateHired(blnValidated, dtmDateHired)
                    If blnValidated = True Then
                        Call Get_And_Validate_dtmDateFired(blnValidated, dtmDateFired)
                        If blnValidated = True Then
                            Call Get_And_Validate_dtmDateLicense(blnValidated, dtmDateLicense)
                            If blnValidated = True Then
                                Call Get_And_Validate_PilotRole(blnValidated)
                                If blnValidated = True Then
                                    Get_And_Validate_strUsername(blnValidated, strUsername)
                                    If blnValidated = True Then
                                        Get_And_Validate_strPassword(blnValidated, strPassword)
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    'Gets and Validates First Name
    Private Sub Get_And_Validate_strFirstName(ByRef blnValidated As Boolean, ByRef strFirstName As String)
        If String.IsNullOrEmpty(txtFirstName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a First Name.")
            blnValidated = False
            txtFirstName.Focus()
        Else
            strFirstName = txtFirstName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Last Name
    Private Sub Get_And_Validate_strLastName(ByRef blnValidated As Boolean, ByRef strLastName As String)
        If String.IsNullOrEmpty(txtLastName.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Last Name.")
            blnValidated = False
            txtLastName.Focus()
        Else
            strLastName = txtLastName.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Gets and Validates EmployeeID
    Private Sub Get_And_Validate_strEmployeeID(ByRef blnValidated As Boolean, ByRef strEmployeeID As String)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        If IsNumeric(txtEmployeeID.Text.Replace(" ", "")) = False Then
            MessageBox.Show("Please enter a 5 digit Employee ID")
            blnValidated = False
        Else
            strEmployeeID = txtEmployeeID.Text.Replace(" ", "")
            If strEmployeeID.Length <> 5 Then
                MessageBox.Show("Please enter a 5 digit Employee ID")
                txtEmployeeID.Focus()
                blnValidated = False
            Else
                strSelect = "SELECT COUNT(strEmployeeID) AS DoesExist FROM TEmployees WHERE strEmployeeID = '" & strEmployeeID & "'"
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader
                drSourceTable.Read()
                If drSourceTable("DoesExist") = 0 Then
                    blnValidated = True
                Else
                    MessageBox.Show("Given EmployeeID already exists in the database. Please enter a new one.")
                    blnValidated = False
                End If
            End If
        End If
    End Sub
    'Gets And Validates Date Hired
    Private Sub Get_And_Validate_dtmDateHired(ByRef blnValidated As Boolean, ByRef dtmDateHired As Date)
        If Date.TryParse(dtpDateHired.Value, dtmDateHired) = False Then
            MessageBox.Show("Please select a Hiring Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Date Fired
    Private Sub Get_And_Validate_dtmDateFired(ByRef blnValidated As Boolean, ByRef dtmDateFired As Date)
        If Date.TryParse(dtpDateFired.Value, dtmDateFired) = False Then
            MessageBox.Show("Please select a Firing Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates Date License
    Private Sub Get_And_Validate_dtmDateLicense(ByRef blnValidated As Boolean, ByRef dtmDateLicense As Date)
        If Date.TryParse(dtpDateLicense.Value, dtmDateLicense) = False Then
            MessageBox.Show("Please select a License Acquired Date")
            blnValidated = False
        Else
            blnValidated = True
        End If
    End Sub
    'Validates Pilot Role
    Private Sub Get_And_Validate_PilotRole(ByRef blnValidated As Boolean)
        If cboPilotRoles.SelectedIndex = -1 Then
            MessageBox.Show("Please Select a Pilot Role")
            blnValidated = False
            cboPilotRoles.Focus()
        Else
            blnValidated = True
        End If
    End Sub
    'Gets and Validates strUsername
    Private Sub Get_And_Validate_strUsername(ByRef blnValidated As Boolean, ByRef strUsername As String)
        If String.IsNullOrEmpty(txtUsername.Text.Replace(" ", "")) Then
            MessageBox.Show("Please enter a Username.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strUsername = txtUsername.Text.Replace(" ", "")
            blnValidated = True
        End If
    End Sub
    'Getting and Validating strPassword
    Private Sub Get_And_Validate_strPassword(ByRef blnValidated As Boolean, ByRef strPassword As String)
        If String.IsNullOrEmpty(txtPassword.Text) Then
            MessageBox.Show("Please enter a Passoword.")
            blnValidated = False
            txtUsername.Focus()
        Else
            strPassword = txtPassword.Text
            blnValidated = True
        End If
    End Sub
    'Adds Pilot to Database
    Private Sub Add_Pilot(ByRef strFirstName As String, ByRef strLastName As String, ByRef strEmployeeID As String, ByRef dtmDateHired As String, ByRef dtmDateFired As String, ByRef dtmDateLicense As String, ByRef strUsername As String, ByRef strPassword As String)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim strEmpInsert As String
        Dim cmdEmpInsert As OleDb.OleDbCommand
        Dim strInsert As String
        Dim cmdInsert As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim intEmpNextPrimaryKey As Integer
        Dim intPilotNextPrimaryKey As Integer
        Dim intRowsAffected As Integer

        'Opening the Database
        If OpenDatabaseConnectionSQLServer() = False Then

            ' No, warn the user ...
            MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        strSelect = "SELECT MAX(intEmployeePK) + 1 AS intEmpNextPrimaryKey " &
                    "FROM TEmployees "


        'Running the Select Statement
        cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
        drSourceTable = cmdSelect.ExecuteReader

        'Checking if it is Null And Setting intNextPrimaryKey

        drSourceTable.Read()

        If drSourceTable.IsDBNull(0) = True Then
            intEmpNextPrimaryKey = 1
        Else
            intEmpNextPrimaryKey = CInt(drSourceTable(intEmpNextPrimaryKey))
        End If

        strEmpInsert = "INSERT INTO TEmployees (intEmployeePK, strUsername, strPassword, intEmployeeRoleID, strEmployeeID) " &
                        "VALUES (" & intEmpNextPrimaryKey & ",'" & strUsername & "','" & strPassword & "'," & 1 & ",'" & strEmployeeID & "')"
        cmdEmpInsert = New OleDb.OleDbCommand(strEmpInsert, m_conAdministrator)

        intRowsAffected = cmdEmpInsert.ExecuteNonQuery()

        If intRowsAffected > 0 Then
            strSelect = "SELECT MAX(intPilotID) + 1 AS intNextPrimaryKey " &
                    "FROM TPilots "
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'Checking if it is Null And Setting intNextPrimaryKey

            drSourceTable.Read()

            If drSourceTable.IsDBNull(0) = True Then
                intPilotNextPrimaryKey = 1
            Else
                intPilotNextPrimaryKey = CInt(drSourceTable(intPilotNextPrimaryKey))
            End If

            strInsert = "INSERT INTO TPilots (intPilotID, strFirstName, strLastName, strEmployeeID, dtmDateofHire, dtmDateofTermination, dtmDateofLicense, intPilotRoleID) " &
                        "VALUES (" & intPilotNextPrimaryKey & ",'" & strFirstName & "','" & strLastName & "','" & strEmployeeID & "','" & dtmDateHired & "'," & dtmDateFired & ",'" & dtmDateLicense & "'," & cboPilotRoles.SelectedValue & ")"


            cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

            intRowsAffected = cmdInsert.ExecuteNonQuery()

            If intRowsAffected > 0 Then
                MessageBox.Show("Pilot Profile has been added.")
            Else
                CloseDatabaseConnection()
            End If
        Else
            MessageBox.Show("Employee Insert Failed")
            CloseDatabaseConnection()
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class